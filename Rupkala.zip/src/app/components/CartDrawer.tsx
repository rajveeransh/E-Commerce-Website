import { useEffect, useRef } from "react";
import { X, ShoppingBag, Plus, Minus, Trash2, ArrowRight, PackageOpen } from "lucide-react";
import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router";
import { motion } from "motion/react";

const SHIPPING_THRESHOLD = 999;
const SHIPPING_FEE = 99;

export function CartDrawer() {
  const { items, isOpen, closeCart, removeFromCart, updateQuantity, subtotal, itemCount } = useCart();
  const navigate = useNavigate();
  const drawerRef = useRef<HTMLDivElement>(null);

  // Close on Escape
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") closeCart(); };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [closeCart]);

  // Lock body scroll
  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  const shipping = subtotal >= SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  const total = subtotal + shipping;
  const progressToFreeShipping = Math.min((subtotal / SHIPPING_THRESHOLD) * 100, 100);
  const remaining = SHIPPING_THRESHOLD - subtotal;

  const handleCheckout = () => {
    closeCart();
    navigate("/checkout");
  };

  if (!isOpen) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 1000,
        display: "flex",
        justifyContent: "flex-end",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={closeCart}
        style={{
          position: "absolute",
          inset: 0,
          background: "rgba(0,0,0,0.7)",
          backdropFilter: "blur(4px)",
        }}
      />

      {/* Drawer Panel */}
      <motion.div
        ref={drawerRef}
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        style={{
          position: "relative",
          width: "100%",
          maxWidth: "480px",
          height: "100vh",
          background: "#111111",
          borderLeft: "1px solid rgba(255,255,255,0.08)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: "24px 28px",
            borderBottom: "1px solid rgba(255,255,255,0.06)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexShrink: 0,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <ShoppingBag size={20} color="rgba(255,255,255,0.9)" strokeWidth={1.5} />
            <div>
              <div style={{ fontSize: "16px", fontWeight: 600, color: "#FFFFFF" }}>Your Cart</div>
              <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)", marginTop: "1px" }}>
                {itemCount} {itemCount === 1 ? "item" : "items"}
              </div>
            </div>
          </div>
          <button
            onClick={closeCart}
            style={{
              width: "36px",
              height: "36px",
              borderRadius: "8px",
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.08)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: "rgba(255,255,255,0.6)",
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.1)";
              (e.currentTarget as HTMLElement).style.color = "#FFFFFF";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.06)";
              (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.6)";
            }}
          >
            <X size={16} />
          </button>
        </div>

        {/* Free Shipping Progress */}
        {items.length > 0 && (
          <div
            style={{
              padding: "14px 28px",
              background: "rgba(79,142,247,0.05)",
              borderBottom: "1px solid rgba(255,255,255,0.04)",
              flexShrink: 0,
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
              <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.5)", letterSpacing: "0.05em" }}>
                {shipping === 0 ? "🎉 Free shipping unlocked!" : `₹${remaining} away from free shipping`}
              </span>
              <span style={{ fontSize: "11px", color: "#4F8EF7", fontWeight: 600 }}>
                {shipping === 0 ? "FREE" : `₹${SHIPPING_THRESHOLD}`}
              </span>
            </div>
            <div
              style={{
                height: "3px",
                background: "rgba(255,255,255,0.08)",
                borderRadius: "100px",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  height: "100%",
                  width: `${progressToFreeShipping}%`,
                  background: "linear-gradient(90deg, #4F8EF7, #7B6CF6)",
                  borderRadius: "100px",
                  transition: "width 0.5s ease",
                }}
              />
            </div>
          </div>
        )}

        {/* Cart Items */}
        <div style={{ flex: 1, overflowY: "auto", padding: "8px 0" }}>
          {items.length === 0 ? (
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                height: "100%",
                padding: "48px 28px",
                textAlign: "center",
              }}
            >
              <div
                style={{
                  width: "80px",
                  height: "80px",
                  borderRadius: "20px",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: "24px",
                  color: "rgba(255,255,255,0.2)",
                }}
              >
                <PackageOpen size={32} strokeWidth={1} />
              </div>
              <h3
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "22px",
                  fontWeight: 600,
                  color: "#FFFFFF",
                  margin: "0 0 10px",
                }}
              >
                Your cart is empty
              </h3>
              <p style={{ fontSize: "14px", color: "rgba(255,255,255,0.4)", margin: "0 0 32px", lineHeight: 1.6 }}>
                Discover pieces that tell your story.
              </p>
              <button
                onClick={() => { closeCart(); navigate("/collection"); }}
                style={{
                  background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
                  border: "none",
                  color: "#FFFFFF",
                  padding: "14px 28px",
                  borderRadius: "8px",
                  fontSize: "13px",
                  fontWeight: 600,
                  cursor: "pointer",
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  fontFamily: "'Inter', sans-serif",
                }}
              >
                Shop Collection <ArrowRight size={14} />
              </button>
            </div>
          ) : (
            <div style={{ padding: "8px 0" }}>
              {items.map((item, idx) => (
                <motion.div
                  key={`${item.productId}-${item.color}-${item.size}`}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  style={{
                    padding: "20px 28px",
                    borderBottom: "1px solid rgba(255,255,255,0.04)",
                    display: "flex",
                    gap: "16px",
                    alignItems: "flex-start",
                  }}
                >
                  {/* Product Image */}
                  <div
                    style={{
                      width: "80px",
                      height: "96px",
                      borderRadius: "10px",
                      overflow: "hidden",
                      flexShrink: 0,
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.08)",
                    }}
                  >
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.name}
                        style={{ width: "100%", height: "100%", objectFit: "cover" }}
                      />
                    ) : (
                      <div
                        style={{
                          width: "100%",
                          height: "100%",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          background: item.color || "#333",
                        }}
                      />
                    )}
                  </div>

                  {/* Info */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div
                      style={{
                        fontFamily: "'Playfair Display', serif",
                        fontSize: "15px",
                        fontWeight: 600,
                        color: "#FFFFFF",
                        marginBottom: "6px",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {item.name}
                    </div>
                    <div style={{ display: "flex", gap: "8px", marginBottom: "12px", flexWrap: "wrap" }}>
                      <span
                        style={{
                          fontSize: "11px",
                          color: "rgba(255,255,255,0.4)",
                          background: "rgba(255,255,255,0.05)",
                          padding: "2px 8px",
                          borderRadius: "100px",
                        }}
                      >
                        {item.colorName || item.color}
                      </span>
                      <span
                        style={{
                          fontSize: "11px",
                          color: "rgba(255,255,255,0.4)",
                          background: "rgba(255,255,255,0.05)",
                          padding: "2px 8px",
                          borderRadius: "100px",
                        }}
                      >
                        {item.size}
                      </span>
                    </div>

                    {/* Qty + Price row */}
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      {/* Quantity controls */}
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "0",
                          background: "rgba(255,255,255,0.05)",
                          border: "1px solid rgba(255,255,255,0.08)",
                          borderRadius: "8px",
                          overflow: "hidden",
                        }}
                      >
                        <button
                          onClick={() => updateQuantity(item.productId, item.color, item.size, item.quantity - 1)}
                          style={{
                            width: "32px",
                            height: "32px",
                            background: "none",
                            border: "none",
                            color: "rgba(255,255,255,0.5)",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            transition: "color 0.2s ease",
                          }}
                          onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = "#FFFFFF")}
                          onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.5)")}
                        >
                          <Minus size={12} />
                        </button>
                        <span
                          style={{
                            width: "28px",
                            textAlign: "center",
                            fontSize: "13px",
                            fontWeight: 600,
                            color: "#FFFFFF",
                          }}
                        >
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.productId, item.color, item.size, item.quantity + 1)}
                          style={{
                            width: "32px",
                            height: "32px",
                            background: "none",
                            border: "none",
                            color: "rgba(255,255,255,0.5)",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            transition: "color 0.2s ease",
                          }}
                          onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = "#FFFFFF")}
                          onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.5)")}
                        >
                          <Plus size={12} />
                        </button>
                      </div>

                      <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
                        <span style={{ fontSize: "15px", fontWeight: 700, color: "#FFFFFF" }}>
                          ₹{(item.price * item.quantity).toLocaleString("en-IN")}
                        </span>
                        <button
                          onClick={() => removeFromCart(item.productId, item.color, item.size)}
                          style={{
                            background: "none",
                            border: "none",
                            color: "rgba(255,255,255,0.3)",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            padding: "4px",
                            borderRadius: "4px",
                            transition: "color 0.2s ease",
                          }}
                          onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = "#E63946")}
                          onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.3)")}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Summary */}
        {items.length > 0 && (
          <div
            style={{
              padding: "24px 28px",
              borderTop: "1px solid rgba(255,255,255,0.06)",
              background: "rgba(255,255,255,0.02)",
              flexShrink: 0,
            }}
          >
            {/* Price breakdown */}
            <div style={{ marginBottom: "16px" }}>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  marginBottom: "8px",
                }}
              >
                <span style={{ fontSize: "13px", color: "rgba(255,255,255,0.45)" }}>Subtotal</span>
                <span style={{ fontSize: "13px", color: "rgba(255,255,255,0.8)", fontWeight: 500 }}>
                  ₹{subtotal.toLocaleString("en-IN")}
                </span>
              </div>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  marginBottom: "12px",
                }}
              >
                <span style={{ fontSize: "13px", color: "rgba(255,255,255,0.45)" }}>Shipping</span>
                <span
                  style={{
                    fontSize: "13px",
                    color: shipping === 0 ? "#22C55E" : "rgba(255,255,255,0.8)",
                    fontWeight: 500,
                  }}
                >
                  {shipping === 0 ? "FREE" : `₹${shipping}`}
                </span>
              </div>
              <div
                style={{
                  height: "1px",
                  background: "rgba(255,255,255,0.06)",
                  marginBottom: "12px",
                }}
              />
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ fontSize: "15px", fontWeight: 600, color: "#FFFFFF" }}>Total</span>
                <span
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "20px",
                    fontWeight: 700,
                    color: "#FFFFFF",
                  }}
                >
                  ₹{total.toLocaleString("en-IN")}
                </span>
              </div>
            </div>

            {/* Checkout Button */}
            <button
              onClick={handleCheckout}
              style={{
                width: "100%",
                padding: "16px 24px",
                background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
                border: "none",
                borderRadius: "10px",
                color: "#FFFFFF",
                fontSize: "13px",
                fontWeight: 700,
                letterSpacing: "0.1em",
                textTransform: "uppercase",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "10px",
                transition: "all 0.3s ease",
                boxShadow: "0 8px 32px rgba(79,142,247,0.35)",
                fontFamily: "'Inter', sans-serif",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.transform = "translateY(-1px)";
                (e.currentTarget as HTMLElement).style.boxShadow = "0 12px 40px rgba(79,142,247,0.5)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
                (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 32px rgba(79,142,247,0.35)";
              }}
            >
              Proceed to Checkout <ArrowRight size={15} strokeWidth={2.5} />
            </button>

            <p style={{ textAlign: "center", fontSize: "11px", color: "rgba(255,255,255,0.25)", margin: "12px 0 0" }}>
              Secure checkout · Free returns · Made in India
            </p>
          </div>
        )}
      </motion.div>
    </div>
  );
}
