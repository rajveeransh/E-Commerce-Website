import { useState } from "react";
import { Star, ChevronLeft, ChevronRight } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Aditya Sharma",
    role: "Streetwear Designer, Delhi",
    avatar: "AS",
    avatarBg: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
    text: "Rupkala completely changed how I think about custom merch. The quality is unreal — the print survived 50+ washes and still looks fresh. The design tool is so intuitive. Ordered 200 pieces for my brand launch.",
    rating: 5,
    product: "Artisan Custom Tee",
    verified: true,
  },
  {
    id: 2,
    name: "Priya Menon",
    role: "Art Director, Bengaluru",
    avatar: "PM",
    avatarBg: "linear-gradient(135deg, #F59E0B, #EF4444)",
    text: "I've tried 6 different custom tee services. Rupkala is in a completely different league. The organic cotton feels premium, the colors are true to screen, and the packaging? Absolutely gorgeous. My team was blown away.",
    rating: 5,
    product: "Monochrome Classic",
    verified: true,
  },
  {
    id: 3,
    name: "Rohan Kapoor",
    role: "Founder, Capsule Studio",
    avatar: "RK",
    avatarBg: "linear-gradient(135deg, #22C55E, #4F8EF7)",
    text: "Ordered 500 units for our studio's annual drop. Zero defects, delivered in 8 days, and the GSM is exactly as advertised. The team even reached out to check if the color profile matched our brand guidelines. 10/10.",
    rating: 5,
    product: "Heritage Print Drop",
    verified: true,
  },
];

export function Testimonials() {
  const [current, setCurrent] = useState(0);

  const prev = () => setCurrent((c) => (c - 1 + testimonials.length) % testimonials.length);
  const next = () => setCurrent((c) => (c + 1) % testimonials.length);

  return (
    <section
      style={{
        backgroundColor: "#0C0C0C",
        padding: "140px 0",
        fontFamily: "'Inter', sans-serif",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Background glow */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          right: "-100px",
          width: "500px",
          height: "500px",
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(79,142,247,0.06) 0%, transparent 70%)",
          transform: "translateY(-50%)",
          pointerEvents: "none",
        }}
      />

      <div style={{ maxWidth: "1440px", margin: "0 auto", padding: "0 48px" }}>
        {/* Header */}
        <div
          style={{
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "space-between",
            marginBottom: "72px",
          }}
        >
          <div>
            <p
              style={{
                fontSize: "11px",
                color: "#4F8EF7",
                fontWeight: 600,
                letterSpacing: "0.2em",
                textTransform: "uppercase",
                marginBottom: "16px",
              }}
            >
              Social Proof
            </p>
            <h2
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(36px, 4vw, 56px)",
                fontWeight: 700,
                color: "#FFFFFF",
                margin: 0,
                lineHeight: 1.1,
                letterSpacing: "-0.02em",
              }}
            >
              What They're
              <br />
              <span
                style={{
                  fontStyle: "italic",
                  color: "rgba(255,255,255,0.45)",
                }}
              >
                Saying.
              </span>
            </h2>
          </div>

          {/* Navigation */}
          <div style={{ display: "flex", gap: "12px" }}>
            <button
              onClick={prev}
              style={{
                width: "48px",
                height: "48px",
                borderRadius: "50%",
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "rgba(255,255,255,0.6)",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                transition: "all 0.2s ease",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = "rgba(79,142,247,0.12)";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(79,142,247,0.3)";
                (e.currentTarget as HTMLElement).style.color = "#4F8EF7";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.1)";
                (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.6)";
              }}
            >
              <ChevronLeft size={18} />
            </button>
            <button
              onClick={next}
              style={{
                width: "48px",
                height: "48px",
                borderRadius: "50%",
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "rgba(255,255,255,0.6)",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                transition: "all 0.2s ease",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = "rgba(79,142,247,0.12)";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(79,142,247,0.3)";
                (e.currentTarget as HTMLElement).style.color = "#4F8EF7";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.1)";
                (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.6)";
              }}
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>

        {/* Testimonial Cards - Desktop: all 3, Mobile: carousel */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
            gap: "24px",
          }}
          className="hidden md:grid"
        >
          {testimonials.map((t) => (
            <TestimonialCard key={t.id} testimonial={t} />
          ))}
        </div>

        {/* Mobile carousel */}
        <div className="md:hidden" style={{ position: "relative" }}>
          <TestimonialCard testimonial={testimonials[current]} />
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              gap: "8px",
              marginTop: "24px",
            }}
          >
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                style={{
                  width: i === current ? "24px" : "8px",
                  height: "8px",
                  borderRadius: "100px",
                  background:
                    i === current ? "#4F8EF7" : "rgba(255,255,255,0.2)",
                  border: "none",
                  cursor: "pointer",
                  transition: "all 0.3s ease",
                  padding: 0,
                }}
              />
            ))}
          </div>
        </div>

        {/* Bottom trust badges */}
        <div
          style={{
            marginTop: "80px",
            display: "flex",
            justifyContent: "center",
            gap: "40px",
            flexWrap: "wrap",
          }}
        >
          {[
            { label: "4.9/5 Rating", sub: "from 3,200+ reviews" },
            { label: "12,000+", sub: "Happy Customers" },
            { label: "99.2%", sub: "Satisfaction Rate" },
          ].map((badge) => (
            <div key={badge.label} style={{ textAlign: "center" }}>
              <div
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "28px",
                  fontWeight: 700,
                  color: "#FFFFFF",
                  lineHeight: 1.2,
                }}
              >
                {badge.label}
              </div>
              <div
                style={{
                  fontSize: "12px",
                  color: "rgba(255,255,255,0.35)",
                  marginTop: "4px",
                  letterSpacing: "0.06em",
                }}
              >
                {badge.sub}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TestimonialCard({
  testimonial,
}: {
  testimonial: (typeof testimonials)[0];
}) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      style={{
        background: hovered ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.025)",
        border: hovered
          ? "1px solid rgba(79,142,247,0.2)"
          : "1px solid rgba(255,255,255,0.06)",
        borderRadius: "20px",
        padding: "36px",
        transition: "all 0.35s ease",
        transform: hovered ? "translateY(-6px)" : "translateY(0)",
        boxShadow: hovered
          ? "0 24px 60px rgba(0,0,0,0.4)"
          : "0 8px 24px rgba(0,0,0,0.2)",
        display: "flex",
        flexDirection: "column",
        gap: "24px",
        cursor: "default",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Stars */}
      <div style={{ display: "flex", gap: "4px" }}>
        {Array.from({ length: testimonial.rating }).map((_, i) => (
          <Star
            key={i}
            size={14}
            fill="#F59E0B"
            color="#F59E0B"
            strokeWidth={0}
          />
        ))}
      </div>

      {/* Quote */}
      <p
        style={{
          fontSize: "15px",
          color: "rgba(255,255,255,0.65)",
          lineHeight: 1.75,
          margin: 0,
          flexGrow: 1,
        }}
      >
        "{testimonial.text}"
      </p>

      {/* Product tag */}
      <div
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: "6px",
          background: "rgba(79,142,247,0.08)",
          border: "1px solid rgba(79,142,247,0.15)",
          borderRadius: "100px",
          padding: "4px 12px",
          fontSize: "11px",
          color: "#4F8EF7",
          fontWeight: 500,
          alignSelf: "flex-start",
        }}
      >
        <span>Purchased:</span>
        <span style={{ fontWeight: 600 }}>{testimonial.product}</span>
      </div>

      {/* Author */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "12px",
          paddingTop: "20px",
          borderTop: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div
          style={{
            width: "44px",
            height: "44px",
            borderRadius: "50%",
            background: testimonial.avatarBg,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "13px",
            fontWeight: 700,
            color: "#FFFFFF",
            flexShrink: 0,
          }}
        >
          {testimonial.avatar}
        </div>
        <div>
          <div
            style={{
              fontSize: "14px",
              fontWeight: 600,
              color: "#FFFFFF",
              display: "flex",
              alignItems: "center",
              gap: "8px",
            }}
          >
            {testimonial.name}
            {testimonial.verified && (
              <span
                style={{
                  width: "16px",
                  height: "16px",
                  borderRadius: "50%",
                  background: "#4F8EF7",
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "9px",
                  color: "#fff",
                }}
              >
                ✓
              </span>
            )}
          </div>
          <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.35)", marginTop: "2px" }}>
            {testimonial.role}
          </div>
        </div>
      </div>
    </div>
  );
}
