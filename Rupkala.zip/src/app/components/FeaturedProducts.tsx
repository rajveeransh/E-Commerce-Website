import { useState } from "react";
import { ShoppingBag, Heart, Eye } from "lucide-react";

const products = [
  {
    id: 1,
    name: "Monochrome Classic",
    price: "₹849",
    originalPrice: "₹1,299",
    tag: "Bestseller",
    tagColor: "#4F8EF7",
    image:
      "https://images.unsplash.com/photo-1589157774617-919700992e4c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibGFjayUyMHRzaGlydCUyMHByb2R1Y3QlMjBmbGF0JTIwbGF5JTIwbWluaW1hbHxlbnwxfHx8fDE3NzE5MzMxNzJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    colors: ["#111111", "#F5F5F5", "#1a3a6b"],
    sizes: ["XS", "S", "M", "L", "XL"],
  },
  {
    id: 2,
    name: "Urban Oversize Tee",
    price: "₹999",
    originalPrice: "₹1,499",
    tag: "New",
    tagColor: "#22C55E",
    image:
      "https://images.unsplash.com/photo-1626160200951-fc4b4f8d4de9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aGl0ZSUyMHRzaGlydCUyMHN0cmVldHdlYXIlMjB1cmJhbiUyMGZhc2hpb258ZW58MXx8fHwxNzcxOTMzMTcyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    colors: ["#F5F5F5", "#E2D5B0", "#6B7280"],
    sizes: ["S", "M", "L", "XL", "XXL"],
  },
  {
    id: 3,
    name: "Heritage Print Drop",
    price: "₹1,199",
    originalPrice: "₹1,799",
    tag: "Limited",
    tagColor: "#F59E0B",
    image:
      "https://images.unsplash.com/photo-1523381294911-8d3cead13475?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwdHNoaXJ0JTIwY29sbGVjdGlvbiUyMGZhc2hpb24lMjBsb29rYm9va3xlbnwxfHx8fDE3NzE5MzMxNzV8MA&ixlib=rb-4.1.0&q=80&w=1080",
    colors: ["#8B5CF6", "#111111", "#F5F5F5"],
    sizes: ["XS", "S", "M", "L"],
  },
  {
    id: 4,
    name: "Artisan Custom Tee",
    price: "₹1,499",
    originalPrice: null,
    tag: "Custom",
    tagColor: "#7B6CF6",
    image:
      "https://images.unsplash.com/photo-1627225924765-552d49cf47ad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0c2hpcnQlMjBtb2NrdXAlMjBjdXN0b20lMjBwcmludCUyMGFwcGFyZWx8ZW58MXx8fHwxNzcxOTMzMTc1fDA&ixlib=rb-4.1.0&q=80&w=1080",
    colors: ["#4F8EF7", "#111111", "#F5F5F5", "#22C55E"],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
  },
];

function ProductCard({ product }: { product: (typeof products)[0] }) {
  const [hovered, setHovered] = useState(false);
  const [liked, setLiked] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const [selectedColor, setSelectedColor] = useState(0);

  const handleAddToCart = () => {
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  return (
    <div
      style={{
        background: "#141414",
        borderRadius: "16px",
        overflow: "hidden",
        border: hovered
          ? "1px solid rgba(79,142,247,0.25)"
          : "1px solid rgba(255,255,255,0.06)",
        transition: "all 0.4s ease",
        transform: hovered ? "translateY(-8px)" : "translateY(0)",
        boxShadow: hovered
          ? "0 32px 64px rgba(0,0,0,0.5), 0 0 0 1px rgba(79,142,247,0.1)"
          : "0 8px 24px rgba(0,0,0,0.2)",
        cursor: "pointer",
        fontFamily: "'Inter', sans-serif",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Image Container */}
      <div style={{ position: "relative", overflow: "hidden", height: "320px" }}>
        <img
          src={product.image}
          alt={product.name}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            transition: "transform 0.6s ease",
            transform: hovered ? "scale(1.06)" : "scale(1)",
            filter: "brightness(0.92) contrast(1.05)",
          }}
        />

        {/* Gradient overlay */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            background:
              "linear-gradient(to top, rgba(20,20,20,0.6) 0%, transparent 50%)",
          }}
        />

        {/* Tag */}
        <div
          style={{
            position: "absolute",
            top: "16px",
            left: "16px",
            background: product.tagColor,
            color: "#fff",
            fontSize: "10px",
            fontWeight: 700,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            padding: "4px 12px",
            borderRadius: "100px",
          }}
        >
          {product.tag}
        </div>

        {/* Action buttons */}
        <div
          style={{
            position: "absolute",
            top: "12px",
            right: "12px",
            display: "flex",
            flexDirection: "column",
            gap: "8px",
            opacity: hovered ? 1 : 0,
            transform: hovered ? "translateX(0)" : "translateX(12px)",
            transition: "all 0.3s ease",
          }}
        >
          <button
            style={{
              width: "40px",
              height: "40px",
              borderRadius: "10px",
              background: "rgba(12,12,12,0.7)",
              backdropFilter: "blur(12px)",
              border: "1px solid rgba(255,255,255,0.1)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: liked ? "#F87171" : "rgba(255,255,255,0.7)",
              transition: "all 0.2s ease",
            }}
            onClick={(e) => {
              e.stopPropagation();
              setLiked(!liked);
            }}
          >
            <Heart size={16} fill={liked ? "currentColor" : "none"} />
          </button>
          <button
            style={{
              width: "40px",
              height: "40px",
              borderRadius: "10px",
              background: "rgba(12,12,12,0.7)",
              backdropFilter: "blur(12px)",
              border: "1px solid rgba(255,255,255,0.1)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: "rgba(255,255,255,0.7)",
            }}
          >
            <Eye size={16} />
          </button>
        </div>

        {/* Color swatches on hover */}
        <div
          style={{
            position: "absolute",
            bottom: "16px",
            left: "16px",
            display: "flex",
            gap: "8px",
            opacity: hovered ? 1 : 0,
            transition: "opacity 0.3s ease",
          }}
        >
          {product.colors.map((color, i) => (
            <div
              key={i}
              onClick={(e) => {
                e.stopPropagation();
                setSelectedColor(i);
              }}
              style={{
                width: "20px",
                height: "20px",
                borderRadius: "50%",
                backgroundColor: color,
                border:
                  selectedColor === i
                    ? "2px solid #4F8EF7"
                    : "2px solid rgba(255,255,255,0.2)",
                cursor: "pointer",
                transition: "border-color 0.2s ease",
              }}
            />
          ))}
        </div>
      </div>

      {/* Card Body */}
      <div style={{ padding: "20px 20px 24px" }}>
        <h3
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "17px",
            fontWeight: 600,
            color: "#FFFFFF",
            margin: "0 0 8px",
            letterSpacing: "-0.01em",
          }}
        >
          {product.name}
        </h3>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
            marginBottom: "20px",
          }}
        >
          <span
            style={{ fontSize: "18px", fontWeight: 700, color: "#FFFFFF" }}
          >
            {product.price}
          </span>
          {product.originalPrice && (
            <span
              style={{
                fontSize: "13px",
                color: "rgba(255,255,255,0.35)",
                textDecoration: "line-through",
              }}
            >
              {product.originalPrice}
            </span>
          )}
          {product.originalPrice && (
            <span
              style={{
                fontSize: "11px",
                color: "#22C55E",
                fontWeight: 600,
              }}
            >
              {Math.round(
                (1 -
                  parseInt(product.price.replace(/[₹,]/g, "")) /
                    parseInt(product.originalPrice.replace(/[₹,]/g, ""))) *
                  100
              )}
              % off
            </span>
          )}
        </div>

        <button
          onClick={handleAddToCart}
          style={{
            width: "100%",
            padding: "13px 20px",
            borderRadius: "8px",
            background: addedToCart
              ? "linear-gradient(135deg, #22C55E, #16A34A)"
              : hovered
              ? "linear-gradient(135deg, #4F8EF7, #7B6CF6)"
              : "rgba(255,255,255,0.06)",
            border: addedToCart
              ? "none"
              : hovered
              ? "none"
              : "1px solid rgba(255,255,255,0.12)",
            color: "#FFFFFF",
            fontSize: "12px",
            fontWeight: 600,
            letterSpacing: "0.1em",
            textTransform: "uppercase",
            cursor: "pointer",
            transition: "all 0.3s ease",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            fontFamily: "'Inter', sans-serif",
          }}
        >
          <ShoppingBag size={15} strokeWidth={1.8} />
          {addedToCart ? "Added to Cart!" : "Add to Cart"}
        </button>
      </div>
    </div>
  );
}

export function FeaturedProducts() {
  return (
    <section
      style={{
        backgroundColor: "#0C0C0C",
        padding: "120px 0",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <div style={{ maxWidth: "1440px", margin: "0 auto", padding: "0 48px" }}>
        {/* Header */}
        <div
          style={{
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "space-between",
            marginBottom: "64px",
          }}
        >
          <div>
            <p
              style={{
                fontSize: "11px",
                color: "#4F8EF7",
                fontWeight: 600,
                letterSpacing: "0.2em",
                textTransform: "uppercase",
                marginBottom: "16px",
              }}
            >
              Featured
            </p>
            <h2
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(36px, 4vw, 56px)",
                fontWeight: 700,
                color: "#FFFFFF",
                margin: 0,
                lineHeight: 1.1,
                letterSpacing: "-0.02em",
              }}
            >
              Our Collection
            </h2>
          </div>
          <a
            href="#"
            style={{
              color: "rgba(255,255,255,0.5)",
              textDecoration: "none",
              fontSize: "13px",
              fontWeight: 500,
              letterSpacing: "0.08em",
              borderBottom: "1px solid rgba(255,255,255,0.2)",
              paddingBottom: "2px",
              transition: "color 0.2s ease",
            }}
            onMouseEnter={(e) =>
              ((e.target as HTMLElement).style.color = "#FFFFFF")
            }
            onMouseLeave={(e) =>
              ((e.target as HTMLElement).style.color =
                "rgba(255,255,255,0.5)")
            }
          >
            View All Products →
          </a>
        </div>

        {/* Products Grid */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "24px",
          }}
        >
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
