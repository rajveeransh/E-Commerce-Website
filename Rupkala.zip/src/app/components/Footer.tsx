import { useState } from "react";
import { Instagram, Twitter, Youtube, Linkedin, ArrowRight } from "lucide-react";

const links = {
  Shop: ["New Arrivals", "Bestsellers", "Custom Studio", "Collections", "Sale"],
  Company: ["Our Story", "Sustainability", "Careers", "Press Kit", "Blog"],
  Support: ["Size Guide", "Shipping Info", "Returns", "FAQs", "Contact Us"],
};

const socials = [
  { icon: Instagram, label: "Instagram" },
  { icon: Twitter, label: "Twitter" },
  { icon: Youtube, label: "YouTube" },
  { icon: Linkedin, label: "LinkedIn" },
];

export function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.includes("@")) {
      setSubscribed(true);
      setEmail("");
    }
  };

  return (
    <footer
      style={{
        backgroundColor: "#080808",
        borderTop: "1px solid rgba(255,255,255,0.06)",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Newsletter Banner */}
      <div
        style={{
          background: "linear-gradient(135deg, rgba(79,142,247,0.08) 0%, rgba(123,108,246,0.08) 100%)",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
          padding: "72px 0",
        }}
      >
        <div
          style={{
            maxWidth: "1440px",
            margin: "0 auto",
            padding: "0 48px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: "48px",
            flexWrap: "wrap",
          }}
        >
          <div>
            <h3
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(28px, 3vw, 40px)",
                fontWeight: 700,
                color: "#FFFFFF",
                margin: "0 0 8px",
                lineHeight: 1.2,
              }}
            >
              Drop into the story first.
            </h3>
            <p style={{ fontSize: "14px", color: "rgba(255,255,255,0.4)", margin: 0 }}>
              New drops, exclusive designs, and early access — straight to your inbox.
            </p>
          </div>

          <form
            onSubmit={handleSubscribe}
            style={{ display: "flex", gap: "0", minWidth: "380px" }}
          >
            {subscribed ? (
              <div
                style={{
                  padding: "16px 24px",
                  background: "rgba(34,197,94,0.1)",
                  border: "1px solid rgba(34,197,94,0.3)",
                  borderRadius: "8px",
                  fontSize: "14px",
                  color: "#22C55E",
                  fontWeight: 600,
                  width: "100%",
                  textAlign: "center",
                }}
              >
                ✓ You're on the list!
              </div>
            ) : (
              <>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  style={{
                    flex: 1,
                    padding: "16px 20px",
                    background: "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRight: "none",
                    borderRadius: "8px 0 0 8px",
                    color: "#FFFFFF",
                    fontSize: "14px",
                    outline: "none",
                    fontFamily: "'Inter', sans-serif",
                  }}
                />
                <button
                  type="submit"
                  style={{
                    padding: "16px 28px",
                    background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
                    border: "none",
                    borderRadius: "0 8px 8px 0",
                    color: "#FFFFFF",
                    fontSize: "13px",
                    fontWeight: 600,
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    letterSpacing: "0.06em",
                    transition: "opacity 0.2s ease",
                    fontFamily: "'Inter', sans-serif",
                    whiteSpace: "nowrap",
                  }}
                  onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.opacity = "0.85")}
                  onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.opacity = "1")}
                >
                  Subscribe <ArrowRight size={14} strokeWidth={2} />
                </button>
              </>
            )}
          </form>
        </div>
      </div>

      {/* Main Footer */}
      <div
        style={{
          maxWidth: "1440px",
          margin: "0 auto",
          padding: "80px 48px 48px",
        }}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "2fr 1fr 1fr 1fr",
            gap: "64px",
            marginBottom: "72px",
          }}
        >
          {/* Brand column */}
          <div>
            {/* Logo */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                marginBottom: "24px",
              }}
            >
              <div
                style={{
                  width: "8px",
                  height: "8px",
                  borderRadius: "50%",
                  backgroundColor: "#4F8EF7",
                  boxShadow: "0 0 12px #4F8EF7",
                }}
              />
              <span
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "22px",
                  fontWeight: 700,
                  color: "#FFFFFF",
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                }}
              >
                Rupkala
              </span>
            </div>

            <p
              style={{
                fontSize: "14px",
                color: "rgba(255,255,255,0.38)",
                lineHeight: 1.85,
                marginBottom: "32px",
                maxWidth: "280px",
              }}
            >
              Premium custom t-shirts crafted with intention. Your story, your
              fabric, your art.
            </p>

            {/* Socials */}
            <div style={{ display: "flex", gap: "12px" }}>
              {socials.map(({ icon: Icon, label }) => (
                <a
                  key={label}
                  href="#"
                  aria-label={label}
                  style={{
                    width: "40px",
                    height: "40px",
                    borderRadius: "10px",
                    background: "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "rgba(255,255,255,0.5)",
                    textDecoration: "none",
                    transition: "all 0.2s ease",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.background =
                      "rgba(79,142,247,0.1)";
                    (e.currentTarget as HTMLElement).style.borderColor =
                      "rgba(79,142,247,0.3)";
                    (e.currentTarget as HTMLElement).style.color = "#4F8EF7";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.background =
                      "rgba(255,255,255,0.04)";
                    (e.currentTarget as HTMLElement).style.borderColor =
                      "rgba(255,255,255,0.08)";
                    (e.currentTarget as HTMLElement).style.color =
                      "rgba(255,255,255,0.5)";
                  }}
                >
                  <Icon size={16} strokeWidth={1.5} />
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(links).map(([category, items]) => (
            <div key={category}>
              <h4
                style={{
                  fontSize: "11px",
                  fontWeight: 700,
                  color: "rgba(255,255,255,0.6)",
                  letterSpacing: "0.18em",
                  textTransform: "uppercase",
                  margin: "0 0 24px",
                }}
              >
                {category}
              </h4>
              <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
                {items.map((item) => (
                  <li key={item} style={{ marginBottom: "14px" }}>
                    <a
                      href="#"
                      style={{
                        color: "rgba(255,255,255,0.35)",
                        textDecoration: "none",
                        fontSize: "14px",
                        transition: "color 0.2s ease",
                        display: "inline-block",
                      }}
                      onMouseEnter={(e) =>
                        ((e.target as HTMLElement).style.color = "#FFFFFF")
                      }
                      onMouseLeave={(e) =>
                        ((e.target as HTMLElement).style.color =
                          "rgba(255,255,255,0.35)")
                      }
                    >
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div
          style={{
            paddingTop: "32px",
            borderTop: "1px solid rgba(255,255,255,0.05)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: "16px",
          }}
        >
          <p
            style={{
              fontSize: "12px",
              color: "rgba(255,255,255,0.22)",
              margin: 0,
            }}
          >
            © 2025 Rupkala. All rights reserved. Made with love in India.
          </p>
          <div style={{ display: "flex", gap: "24px" }}>
            {["Privacy Policy", "Terms of Service", "Cookie Policy"].map(
              (item) => (
                <a
                  key={item}
                  href="#"
                  style={{
                    fontSize: "12px",
                    color: "rgba(255,255,255,0.22)",
                    textDecoration: "none",
                    transition: "color 0.2s ease",
                  }}
                  onMouseEnter={(e) =>
                    ((e.target as HTMLElement).style.color =
                      "rgba(255,255,255,0.6)")
                  }
                  onMouseLeave={(e) =>
                    ((e.target as HTMLElement).style.color =
                      "rgba(255,255,255,0.22)")
                  }
                >
                  {item}
                </a>
              )
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}
