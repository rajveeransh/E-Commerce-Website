import { useState, useEffect } from "react";
import { ShoppingBag, Menu, X, Search } from "lucide-react";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [cartCount] = useState(2);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        transition: "all 0.4s ease",
        backgroundColor: scrolled ? "rgba(11,11,11,0.95)" : "transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        borderBottom: scrolled ? "1px solid rgba(255,255,255,0.06)" : "none",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <nav
        style={{
          maxWidth: "1440px",
          margin: "0 auto",
          padding: "0 48px",
          height: "80px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <div
            style={{
              width: "8px",
              height: "8px",
              borderRadius: "50%",
              backgroundColor: "#4F8EF7",
              boxShadow: "0 0 12px #4F8EF7",
            }}
          />
          <span
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "22px",
              fontWeight: 700,
              color: "#FFFFFF",
              letterSpacing: "0.08em",
              textTransform: "uppercase",
            }}
          >
            Rupkala
          </span>
        </div>

        {/* Desktop Nav Links */}
        <ul
          style={{
            display: "flex",
            gap: "40px",
            listStyle: "none",
            margin: 0,
            padding: 0,
          }}
          className="hidden md:flex"
        >
          {["Collection", "Custom", "Stories", "About"].map((item) => (
            <li key={item}>
              <a
                href="#"
                style={{
                  color: "rgba(255,255,255,0.65)",
                  textDecoration: "none",
                  fontSize: "13px",
                  fontWeight: 500,
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  transition: "color 0.2s ease",
                }}
                onMouseEnter={(e) =>
                  ((e.target as HTMLElement).style.color = "#FFFFFF")
                }
                onMouseLeave={(e) =>
                  ((e.target as HTMLElement).style.color =
                    "rgba(255,255,255,0.65)")
                }
              >
                {item}
              </a>
            </li>
          ))}
        </ul>

        {/* Right Icons */}
        <div style={{ display: "flex", alignItems: "center", gap: "24px" }}>
          <button
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "rgba(255,255,255,0.7)",
              padding: "4px",
              transition: "color 0.2s ease",
            }}
            onMouseEnter={(e) =>
              ((e.currentTarget as HTMLElement).style.color = "#FFFFFF")
            }
            onMouseLeave={(e) =>
              ((e.currentTarget as HTMLElement).style.color =
                "rgba(255,255,255,0.7)")
            }
          >
            <Search size={18} strokeWidth={1.5} />
          </button>

          <button
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "rgba(255,255,255,0.7)",
              padding: "4px",
              position: "relative",
              transition: "color 0.2s ease",
            }}
            onMouseEnter={(e) =>
              ((e.currentTarget as HTMLElement).style.color = "#FFFFFF")
            }
            onMouseLeave={(e) =>
              ((e.currentTarget as HTMLElement).style.color =
                "rgba(255,255,255,0.7)")
            }
          >
            <ShoppingBag size={18} strokeWidth={1.5} />
            <span
              style={{
                position: "absolute",
                top: "-4px",
                right: "-4px",
                background: "#4F8EF7",
                color: "#fff",
                fontSize: "9px",
                fontWeight: 700,
                width: "16px",
                height: "16px",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {cartCount}
            </span>
          </button>

          <button
            style={{
              background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
              border: "none",
              cursor: "pointer",
              color: "#FFFFFF",
              padding: "10px 24px",
              borderRadius: "4px",
              fontSize: "12px",
              fontWeight: 600,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              transition: "all 0.25s ease",
              boxShadow: "0 4px 20px rgba(79,142,247,0.3)",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.transform =
                "translateY(-1px)";
              (e.currentTarget as HTMLElement).style.boxShadow =
                "0 8px 28px rgba(79,142,247,0.45)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
              (e.currentTarget as HTMLElement).style.boxShadow =
                "0 4px 20px rgba(79,142,247,0.3)";
            }}
          >
            Design Now
          </button>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden"
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "rgba(255,255,255,0.8)",
            }}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {menuOpen && (
        <div
          style={{
            background: "#0C0C0C",
            borderTop: "1px solid rgba(255,255,255,0.06)",
            padding: "24px 48px 32px",
          }}
          className="md:hidden"
        >
          {["Collection", "Custom", "Stories", "About"].map((item) => (
            <a
              key={item}
              href="#"
              style={{
                display: "block",
                color: "rgba(255,255,255,0.7)",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: 500,
                letterSpacing: "0.1em",
                textTransform: "uppercase",
                padding: "12px 0",
                borderBottom: "1px solid rgba(255,255,255,0.04)",
              }}
            >
              {item}
            </a>
          ))}
        </div>
      )}
    </header>
  );
}
