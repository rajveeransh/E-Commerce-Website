export function BrandStory() {
  return (
    <section
      style={{
        backgroundColor: "#080808",
        padding: "160px 0",
        position: "relative",
        overflow: "hidden",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Subtle large text background */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          pointerEvents: "none",
          overflow: "hidden",
        }}
      >
        <span
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(120px, 18vw, 280px)",
            fontWeight: 900,
            color: "rgba(255,255,255,0.018)",
            letterSpacing: "-0.04em",
            whiteSpace: "nowrap",
            userSelect: "none",
          }}
        >
          RUPKALA
        </span>
      </div>

      <div
        style={{
          maxWidth: "1440px",
          margin: "0 auto",
          padding: "0 48px",
          position: "relative",
          zIndex: 1,
        }}
      >
        {/* Top row */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 2fr",
            gap: "80px",
            alignItems: "start",
            marginBottom: "100px",
          }}
        >
          <div>
            <p
              style={{
                fontSize: "11px",
                color: "#4F8EF7",
                fontWeight: 600,
                letterSpacing: "0.2em",
                textTransform: "uppercase",
                marginBottom: "24px",
              }}
            >
              Our Story
            </p>
            <div
              style={{
                width: "48px",
                height: "2px",
                background: "linear-gradient(90deg, #4F8EF7, #7B6CF6)",
                marginBottom: "32px",
              }}
            />
            <p
              style={{
                fontSize: "14px",
                color: "rgba(255,255,255,0.4)",
                lineHeight: 1.9,
              }}
            >
              Founded in 2022 in Mumbai, Rupkala was born from a simple belief:
              clothing is a canvas, not a commodity.
            </p>
          </div>

          <div>
            <h2
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(38px, 4.5vw, 64px)",
                fontWeight: 700,
                color: "#FFFFFF",
                margin: "0 0 32px",
                lineHeight: 1.1,
                letterSpacing: "-0.02em",
              }}
            >
              We don't sell t-shirts.
              <br />
              <span
                style={{
                  background:
                    "linear-gradient(135deg, #4F8EF7 0%, #7B6CF6 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                We sell identity.
              </span>
            </h2>
            <p
              style={{
                fontSize: "16px",
                color: "rgba(255,255,255,0.45)",
                lineHeight: 1.85,
                maxWidth: "600px",
              }}
            >
              Rupkala means "the art of beauty." Every piece we create is a
              deliberate act of expression — crafted from premium organic cotton,
              printed with archival-grade inks, and designed with intention. We
              partner with local artisans and ethical factories because the story
              of how something is made matters just as much as the story it tells.
            </p>
          </div>
        </div>

        {/* Values row */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: "1px",
            background: "rgba(255,255,255,0.05)",
            borderRadius: "16px",
            overflow: "hidden",
          }}
          className="grid-cols-2 md:grid-cols-4"
        >
          {[
            {
              number: "01",
              title: "Ethically Made",
              desc: "100% fair-trade certified factories",
            },
            {
              number: "02",
              title: "Eco Materials",
              desc: "GOTS certified organic cotton",
            },
            {
              number: "03",
              title: "Local Craft",
              desc: "Partnered with 40+ Indian artisans",
            },
            {
              number: "04",
              title: "Carbon Neutral",
              desc: "Net-zero since 2024",
            },
          ].map((item) => (
            <div
              key={item.number}
              style={{
                background: "#0C0C0C",
                padding: "48px 40px",
                transition: "background 0.3s ease",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = "#141414";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = "#0C0C0C";
              }}
            >
              <div
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "48px",
                  fontWeight: 800,
                  background: "linear-gradient(135deg, rgba(79,142,247,0.3), rgba(123,108,246,0.3))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                  lineHeight: 1,
                  marginBottom: "16px",
                }}
              >
                {item.number}
              </div>
              <div
                style={{
                  fontSize: "16px",
                  fontWeight: 600,
                  color: "#FFFFFF",
                  marginBottom: "8px",
                }}
              >
                {item.title}
              </div>
              <div style={{ fontSize: "13px", color: "rgba(255,255,255,0.35)" }}>
                {item.desc}
              </div>
            </div>
          ))}
        </div>

        {/* Large pull quote */}
        <div
          style={{
            marginTop: "120px",
            textAlign: "center",
            position: "relative",
          }}
        >
          <div
            style={{
              fontSize: "80px",
              color: "rgba(79,142,247,0.15)",
              fontFamily: "Georgia, serif",
              lineHeight: 0.5,
              marginBottom: "24px",
            }}
          >
            "
          </div>
          <blockquote
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(24px, 3vw, 40px)",
              fontWeight: 500,
              color: "rgba(255,255,255,0.75)",
              lineHeight: 1.5,
              margin: "0 auto",
              maxWidth: "800px",
              fontStyle: "italic",
              letterSpacing: "-0.01em",
            }}
          >
            Fashion is the armor to survive the reality of everyday life.
            Rupkala gives you that armor — tailored to your truth.
          </blockquote>
          <div
            style={{
              marginTop: "24px",
              fontSize: "12px",
              color: "rgba(255,255,255,0.3)",
              letterSpacing: "0.15em",
              textTransform: "uppercase",
            }}
          >
            — Ananya Roy, Co-founder
          </div>
        </div>
      </div>
    </section>
  );
}