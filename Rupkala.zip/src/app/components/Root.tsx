import { useState } from "react";
import { Outlet, ScrollRestoration } from "react-router";
import { Navbar } from "./Navbar";
import { CartDrawer } from "./CartDrawer";
import { AuthModal } from "./AuthModal";
import { SearchModal } from "./SearchModal";
import { Toaster } from "sonner";

export function Root() {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <div
      style={{
        backgroundColor: "#0C0C0C",
        minHeight: "100vh",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <ScrollRestoration />
      <Toaster
        theme="dark"
        toastOptions={{
          style: {
            background: "#1A1A1A",
            border: "1px solid rgba(255,255,255,0.1)",
            color: "#FFFFFF",
            fontFamily: "'Inter', sans-serif",
          },
        }}
      />
      <Navbar onSearchOpen={() => setSearchOpen(true)} />
      <CartDrawer />
      <AuthModal />
      <SearchModal isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
      <Outlet />
    </div>
  );
}
