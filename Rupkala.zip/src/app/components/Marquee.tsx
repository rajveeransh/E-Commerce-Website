export function Marquee() {
  const items = [
    "Wear Your Story",
    "Premium Organic Cotton",
    "Custom Designs",
    "Made In India",
    "Ethically Crafted",
    "12,000+ Happy Customers",
    "Free Shipping Over ₹999",
    "100% Satisfaction Guaranteed",
  ];

  const doubled = [...items, ...items];

  return (
    <div
      style={{
        backgroundColor: "#0A0A0A",
        borderTop: "1px solid rgba(255,255,255,0.05)",
        borderBottom: "1px solid rgba(255,255,255,0.05)",
        padding: "18px 0",
        overflow: "hidden",
        position: "relative",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Fade edges */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "120px",
          height: "100%",
          background: "linear-gradient(to right, #0A0A0A, transparent)",
          zIndex: 1,
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "absolute",
          top: 0,
          right: 0,
          width: "120px",
          height: "100%",
          background: "linear-gradient(to left, #0A0A0A, transparent)",
          zIndex: 1,
          pointerEvents: "none",
        }}
      />

      <div
        style={{
          display: "flex",
          animation: "marqueeScroll 28s linear infinite",
          width: "max-content",
        }}
      >
        {doubled.map((item, i) => (
          <div
            key={i}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "32px",
              padding: "0 32px",
              whiteSpace: "nowrap",
            }}
          >
            <span
              style={{
                fontSize: "12px",
                fontWeight: 600,
                letterSpacing: "0.15em",
                textTransform: "uppercase",
                color: i % 3 === 0
                  ? "#4F8EF7"
                  : "rgba(255,255,255,0.4)",
              }}
            >
              {item}
            </span>
            <span
              style={{
                width: "4px",
                height: "4px",
                borderRadius: "50%",
                background: "rgba(255,255,255,0.15)",
                display: "inline-block",
                flexShrink: 0,
              }}
            />
          </div>
        ))}
      </div>

      <style>{`
        @keyframes marqueeScroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
