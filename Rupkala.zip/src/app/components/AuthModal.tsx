import { useState, useEffect } from "react";
import { X, Eye, EyeOff, User, Mail, Lock, ArrowRight, CheckCircle } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { motion } from "motion/react";

export function AuthModal() {
  const { isAuthOpen, closeAuth, authMode, setAuthMode, signIn, signUp, user } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  // Close if user is already logged in
  useEffect(() => {
    if (user && isAuthOpen) closeAuth();
  }, [user, isAuthOpen, closeAuth]);

  // Reset form on mode change
  useEffect(() => {
    setError(null);
    setSuccess(false);
    setName("");
    setEmail("");
    setPassword("");
  }, [authMode]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") closeAuth(); };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [closeAuth]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      if (authMode === "login") {
        const result = await signIn(email, password);
        if (result.error) {
          setError(result.error);
        } else {
          setSuccess(true);
          setTimeout(() => closeAuth(), 1500);
        }
      } else {
        if (!name.trim()) {
          setError("Please enter your full name.");
          setIsSubmitting(false);
          return;
        }
        if (password.length < 6) {
          setError("Password must be at least 6 characters.");
          setIsSubmitting(false);
          return;
        }
        const result = await signUp(email, password, name);
        if (result.error) {
          setError(result.error);
        } else {
          setSuccess(true);
          setTimeout(() => closeAuth(), 1500);
        }
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isAuthOpen) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 2000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        onClick={closeAuth}
        style={{
          position: "absolute",
          inset: 0,
          background: "rgba(0,0,0,0.8)",
          backdropFilter: "blur(8px)",
        }}
      />

      {/* Modal */}
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ type: "spring", damping: 28, stiffness: 300 }}
        style={{
          position: "relative",
          width: "100%",
          maxWidth: "420px",
          background: "#141414",
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: "20px",
          overflow: "hidden",
          boxShadow: "0 40px 80px rgba(0,0,0,0.6)",
        }}
      >
        {/* Top gradient bar */}
        <div
          style={{
            height: "2px",
            background: "linear-gradient(90deg, #4F8EF7, #7B6CF6)",
          }}
        />

        <div style={{ padding: "32px 36px" }}>
          {/* Close */}
          <button
            onClick={closeAuth}
            style={{
              position: "absolute",
              top: "18px",
              right: "18px",
              width: "32px",
              height: "32px",
              borderRadius: "8px",
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.08)",
              color: "rgba(255,255,255,0.5)",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.1)";
              (e.currentTarget as HTMLElement).style.color = "#FFFFFF";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.06)";
              (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.5)";
            }}
          >
            <X size={14} />
          </button>

          {/* Logo */}
          <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "28px" }}>
            <div
              style={{
                width: "8px",
                height: "8px",
                borderRadius: "50%",
                backgroundColor: "#4F8EF7",
                boxShadow: "0 0 8px #4F8EF7",
              }}
            />
            <span
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "18px",
                fontWeight: 700,
                color: "#FFFFFF",
                letterSpacing: "0.08em",
                textTransform: "uppercase",
              }}
            >
              Rupkala
            </span>
          </div>

          {success ? (
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                textAlign: "center",
                padding: "24px 0",
              }}
            >
              <CheckCircle size={56} color="#22C55E" strokeWidth={1.5} style={{ marginBottom: "20px" }} />
              <h3
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "22px",
                  fontWeight: 700,
                  color: "#FFFFFF",
                  margin: "0 0 8px",
                }}
              >
                {authMode === "login" ? "Welcome back!" : "Account created!"}
              </h3>
              <p style={{ fontSize: "14px", color: "rgba(255,255,255,0.45)", margin: 0 }}>
                {authMode === "login" ? "You're signed in. Redirecting..." : "You're all set. Redirecting..."}
              </p>
            </div>
          ) : (
            <>
              {/* Heading */}
              <h2
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "26px",
                  fontWeight: 700,
                  color: "#FFFFFF",
                  margin: "0 0 8px",
                  letterSpacing: "-0.01em",
                }}
              >
                {authMode === "login" ? "Welcome back." : "Create your account."}
              </h2>
              <p style={{ fontSize: "13px", color: "rgba(255,255,255,0.4)", margin: "0 0 28px" }}>
                {authMode === "login"
                  ? "Sign in to access your orders and designs."
                  : "Join 12,000+ customers wearing their story."}
              </p>

              {/* Tabs */}
              <div
                style={{
                  display: "flex",
                  background: "rgba(255,255,255,0.04)",
                  borderRadius: "10px",
                  padding: "4px",
                  marginBottom: "24px",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                {(["login", "signup"] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setAuthMode(mode)}
                    style={{
                      flex: 1,
                      padding: "10px",
                      borderRadius: "7px",
                      border: "none",
                      cursor: "pointer",
                      fontSize: "12px",
                      fontWeight: 600,
                      letterSpacing: "0.08em",
                      textTransform: "uppercase",
                      transition: "all 0.25s ease",
                      background: authMode === mode ? "rgba(255,255,255,0.1)" : "transparent",
                      color: authMode === mode ? "#FFFFFF" : "rgba(255,255,255,0.35)",
                      fontFamily: "'Inter', sans-serif",
                    }}
                  >
                    {mode === "login" ? "Sign In" : "Sign Up"}
                  </button>
                ))}
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                {authMode === "signup" && (
                  <InputField
                    icon={<User size={15} />}
                    placeholder="Full Name"
                    type="text"
                    value={name}
                    onChange={setName}
                    required
                  />
                )}
                <InputField
                  icon={<Mail size={15} />}
                  placeholder="Email Address"
                  type="email"
                  value={email}
                  onChange={setEmail}
                  required
                />
                <div style={{ position: "relative" }}>
                  <InputField
                    icon={<Lock size={15} />}
                    placeholder="Password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={setPassword}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    style={{
                      position: "absolute",
                      right: "14px",
                      top: "50%",
                      transform: "translateY(-50%)",
                      background: "none",
                      border: "none",
                      color: "rgba(255,255,255,0.35)",
                      cursor: "pointer",
                      padding: "4px",
                      display: "flex",
                    }}
                  >
                    {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>

                {error && (
                  <div
                    style={{
                      padding: "10px 14px",
                      background: "rgba(230,57,70,0.1)",
                      border: "1px solid rgba(230,57,70,0.25)",
                      borderRadius: "8px",
                      fontSize: "13px",
                      color: "#E63946",
                    }}
                  >
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting}
                  style={{
                    width: "100%",
                    padding: "15px 24px",
                    background: isSubmitting
                      ? "rgba(79,142,247,0.5)"
                      : "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
                    border: "none",
                    borderRadius: "10px",
                    color: "#FFFFFF",
                    fontSize: "13px",
                    fontWeight: 700,
                    letterSpacing: "0.1em",
                    textTransform: "uppercase",
                    cursor: isSubmitting ? "not-allowed" : "pointer",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "8px",
                    transition: "all 0.3s ease",
                    boxShadow: "0 6px 24px rgba(79,142,247,0.35)",
                    marginTop: "4px",
                    fontFamily: "'Inter', sans-serif",
                  }}
                >
                  {isSubmitting ? (
                    <span>Please wait...</span>
                  ) : (
                    <>
                      {authMode === "login" ? "Sign In" : "Create Account"}
                      <ArrowRight size={14} strokeWidth={2.5} />
                    </>
                  )}
                </button>
              </form>

              <p
                style={{
                  textAlign: "center",
                  fontSize: "12px",
                  color: "rgba(255,255,255,0.25)",
                  marginTop: "20px",
                  lineHeight: 1.6,
                }}
              >
                By continuing, you agree to our{" "}
                <span style={{ color: "rgba(255,255,255,0.45)", cursor: "pointer" }}>Terms</span> &{" "}
                <span style={{ color: "rgba(255,255,255,0.45)", cursor: "pointer" }}>Privacy Policy</span>.
              </p>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}

function InputField({
  icon,
  placeholder,
  type,
  value,
  onChange,
  required,
}: {
  icon: React.ReactNode;
  placeholder: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "12px",
        background: "rgba(255,255,255,0.04)",
        border: `1px solid ${focused ? "rgba(79,142,247,0.5)" : "rgba(255,255,255,0.08)"}`,
        borderRadius: "10px",
        padding: "0 16px",
        transition: "border-color 0.2s ease",
      }}
    >
      <span style={{ color: "rgba(255,255,255,0.3)", flexShrink: 0 }}>{icon}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          flex: 1,
          background: "none",
          border: "none",
          outline: "none",
          padding: "14px 0",
          fontSize: "14px",
          color: "#FFFFFF",
          fontFamily: "'Inter', sans-serif",
        }}
      />
    </div>
  );
}
