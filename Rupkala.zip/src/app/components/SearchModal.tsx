import { useState, useEffect, useRef } from "react";
import { Search, X, ArrowRight, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router";
import { projectId, publicAnonKey } from "/utils/supabase/info";
import { motion } from "motion/react";

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-40f0d309`;

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice: number | null;
  image: string;
  tag: string;
  tagColor: string;
  category: string;
}

const TRENDING = ["Monochrome Classic", "Oversized Tee", "Custom Design", "Heritage Print", "Minimal Type"];

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
      setQuery("");
      setResults([]);
    }
  }, [isOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const res = await fetch(`${API_BASE}/products?search=${encodeURIComponent(query)}`, {
          headers: { Authorization: `Bearer ${publicAnonKey}` },
        });
        const data = await res.json();
        setResults(data.data || []);
      } catch (err) {
        console.log("Search error:", err);
      } finally {
        setIsSearching(false);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [query]);

  const goToProduct = (id: string) => {
    navigate(`/product/${id}`);
    onClose();
  };

  const goToCollection = (q?: string) => {
    navigate(q ? `/collection?search=${encodeURIComponent(q)}` : "/collection");
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 1500,
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        onClick={onClose}
        style={{
          position: "absolute",
          inset: 0,
          background: "rgba(0,0,0,0.85)",
          backdropFilter: "blur(8px)",
        }}
      />

      {/* Search Container */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ type: "spring", damping: 30, stiffness: 400 }}
        style={{
          position: "relative",
          maxWidth: "680px",
          margin: "80px auto 0",
          padding: "0 24px",
        }}
      >
        {/* Search Input */}
        <div
          style={{
            background: "#141414",
            border: "1px solid rgba(79,142,247,0.3)",
            borderRadius: "16px",
            padding: "0 20px",
            display: "flex",
            alignItems: "center",
            gap: "14px",
            boxShadow: "0 24px 64px rgba(0,0,0,0.5), 0 0 0 1px rgba(79,142,247,0.1)",
          }}
        >
          {isSearching ? (
            <div
              style={{
                width: "20px",
                height: "20px",
                border: "2px solid rgba(255,255,255,0.1)",
                borderTop: "2px solid #4F8EF7",
                borderRadius: "50%",
                flexShrink: 0,
                animation: "spin 0.7s linear infinite",
              }}
            />
          ) : (
            <Search size={20} color="rgba(255,255,255,0.4)" />
          )}
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && query.trim()) {
                goToCollection(query);
              }
            }}
            placeholder="Search products, styles, collections..."
            style={{
              flex: 1,
              background: "none",
              border: "none",
              outline: "none",
              padding: "20px 0",
              fontSize: "16px",
              color: "#FFFFFF",
              fontFamily: "'Inter', sans-serif",
            }}
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              style={{
                background: "none",
                border: "none",
                color: "rgba(255,255,255,0.3)",
                cursor: "pointer",
                padding: "4px",
                display: "flex",
              }}
            >
              <X size={16} />
            </button>
          )}
          <button
            onClick={onClose}
            style={{
              padding: "6px 14px",
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: "6px",
              color: "rgba(255,255,255,0.4)",
              fontSize: "11px",
              cursor: "pointer",
              fontFamily: "'Inter', sans-serif",
              letterSpacing: "0.05em",
              flexShrink: 0,
            }}
          >
            ESC
          </button>
        </div>

        {/* Results Panel */}
        <div
          style={{
            background: "#141414",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: "16px",
            marginTop: "8px",
            overflow: "hidden",
            boxShadow: "0 24px 64px rgba(0,0,0,0.5)",
          }}
        >
          {/* Trending (when no query) */}
          {!query.trim() && (
            <div style={{ padding: "24px" }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  marginBottom: "16px",
                }}
              >
                <TrendingUp size={14} color="#4F8EF7" />
                <span
                  style={{
                    fontSize: "11px",
                    fontWeight: 600,
                    color: "#4F8EF7",
                    letterSpacing: "0.15em",
                    textTransform: "uppercase",
                  }}
                >
                  Trending
                </span>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                {TRENDING.map((term) => (
                  <button
                    key={term}
                    onClick={() => setQuery(term)}
                    style={{
                      padding: "8px 16px",
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      borderRadius: "100px",
                      color: "rgba(255,255,255,0.65)",
                      fontSize: "13px",
                      cursor: "pointer",
                      fontFamily: "'Inter', sans-serif",
                      transition: "all 0.2s ease",
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.background = "rgba(79,142,247,0.1)";
                      (e.currentTarget as HTMLElement).style.borderColor = "rgba(79,142,247,0.3)";
                      (e.currentTarget as HTMLElement).style.color = "#4F8EF7";
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)";
                      (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.08)";
                      (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.65)";
                    }}
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Search Results */}
          {query.trim() && results.length > 0 && (
            <div>
              <div
                style={{
                  padding: "14px 24px 8px",
                  fontSize: "11px",
                  color: "rgba(255,255,255,0.35)",
                  fontWeight: 600,
                  letterSpacing: "0.15em",
                  textTransform: "uppercase",
                }}
              >
                Products ({results.length})
              </div>
              {results.slice(0, 5).map((product) => (
                <div
                  key={product.id}
                  onClick={() => goToProduct(product.id)}
                  style={{
                    padding: "14px 24px",
                    display: "flex",
                    alignItems: "center",
                    gap: "16px",
                    cursor: "pointer",
                    transition: "background 0.2s ease",
                    borderTop: "1px solid rgba(255,255,255,0.04)",
                  }}
                  onMouseEnter={(e) =>
                    ((e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)")
                  }
                  onMouseLeave={(e) =>
                    ((e.currentTarget as HTMLElement).style.background = "transparent")
                  }
                >
                  <div
                    style={{
                      width: "48px",
                      height: "56px",
                      borderRadius: "8px",
                      overflow: "hidden",
                      flexShrink: 0,
                      background: "rgba(255,255,255,0.05)",
                    }}
                  >
                    {product.image && (
                      <img
                        src={product.image}
                        alt={product.name}
                        style={{ width: "100%", height: "100%", objectFit: "cover" }}
                      />
                    )}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div
                      style={{
                        fontSize: "14px",
                        fontWeight: 600,
                        color: "#FFFFFF",
                        marginBottom: "4px",
                        fontFamily: "'Playfair Display', serif",
                      }}
                    >
                      {product.name}
                    </div>
                    <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)" }}>
                      ₹{product.price.toLocaleString("en-IN")}
                      {product.originalPrice && (
                        <span
                          style={{ textDecoration: "line-through", marginLeft: "8px", opacity: 0.5 }}
                        >
                          ₹{product.originalPrice.toLocaleString("en-IN")}
                        </span>
                      )}
                    </div>
                  </div>
                  <div
                    style={{
                      fontSize: "10px",
                      fontWeight: 700,
                      color: product.tagColor || "#4F8EF7",
                      background: `${product.tagColor || "#4F8EF7"}15`,
                      padding: "3px 10px",
                      borderRadius: "100px",
                      letterSpacing: "0.1em",
                      textTransform: "uppercase",
                    }}
                  >
                    {product.tag}
                  </div>
                </div>
              ))}
              <div
                style={{
                  padding: "14px 24px",
                  borderTop: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <button
                  onClick={() => goToCollection(query)}
                  style={{
                    width: "100%",
                    padding: "10px",
                    background: "rgba(79,142,247,0.08)",
                    border: "1px solid rgba(79,142,247,0.2)",
                    borderRadius: "8px",
                    color: "#4F8EF7",
                    fontSize: "12px",
                    fontWeight: 600,
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "8px",
                    letterSpacing: "0.08em",
                    textTransform: "uppercase",
                    fontFamily: "'Inter', sans-serif",
                    transition: "all 0.2s ease",
                  }}
                >
                  View all results for "{query}" <ArrowRight size={13} />
                </button>
              </div>
            </div>
          )}

          {/* No results */}
          {query.trim() && !isSearching && results.length === 0 && (
            <div style={{ padding: "32px 24px", textAlign: "center" }}>
              <p style={{ fontSize: "15px", color: "rgba(255,255,255,0.45)", margin: 0 }}>
                No products found for "{query}"
              </p>
              <p style={{ fontSize: "13px", color: "rgba(255,255,255,0.25)", margin: "8px 0 0" }}>
                Try a different search or{" "}
                <span
                  onClick={() => goToCollection()}
                  style={{ color: "#4F8EF7", cursor: "pointer" }}
                >
                  browse the full collection
                </span>
              </p>
            </div>
          )}
        </div>
      </motion.div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
