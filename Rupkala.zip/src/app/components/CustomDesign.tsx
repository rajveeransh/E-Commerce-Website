import { useState } from "react";
import { Palette, Type, Layers, Zap, ArrowRight, Check } from "lucide-react";

const features = [
  {
    icon: Palette,
    title: "Choose Colors",
    desc: "Pick from 50+ premium fabric colors",
  },
  {
    icon: Type,
    title: "Add Text & Art",
    desc: "Upload your design or craft it in our editor",
  },
  {
    icon: Layers,
    title: "Select Placement",
    desc: "Front, back, sleeve — you decide",
  },
  {
    icon: Zap,
    title: "Instant Preview",
    desc: "See your tee in real-time before ordering",
  },
];

const teeColors = [
  { name: "Charcoal", hex: "#1C1C1C" },
  { name: "Navy", hex: "#1B2A4A" },
  { name: "Ivory", hex: "#F5F0E8" },
  { name: "Electric Blue", hex: "#4F8EF7" },
  { name: "Sage", hex: "#4A6741" },
];

export function CustomDesign() {
  const [selectedColor, setSelectedColor] = useState(0);
  const [hoveredCta, setHoveredCta] = useState(false);

  const currentColor = teeColors[selectedColor];

  return (
    <section
      style={{
        backgroundColor: "#0F0F0F",
        padding: "140px 0",
        position: "relative",
        overflow: "hidden",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Background accent */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "-200px",
          width: "500px",
          height: "500px",
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(123,108,246,0.06) 0%, transparent 70%)",
          transform: "translateY(-50%)",
          pointerEvents: "none",
        }}
      />

      <div
        style={{
          maxWidth: "1440px",
          margin: "0 auto",
          padding: "0 48px",
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "96px",
          alignItems: "center",
        }}
      >
        {/* Left: Text Content */}
        <div>
          <p
            style={{
              fontSize: "11px",
              color: "#7B6CF6",
              fontWeight: 600,
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              marginBottom: "20px",
            }}
          >
            Customization Studio
          </p>
          <h2
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(36px, 4vw, 54px)",
              fontWeight: 700,
              color: "#FFFFFF",
              margin: "0 0 24px",
              lineHeight: 1.1,
              letterSpacing: "-0.02em",
            }}
          >
            Make It
            <br />
            <span
              style={{
                background: "linear-gradient(135deg, #7B6CF6 0%, #4F8EF7 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Unmistakably Yours.
            </span>
          </h2>
          <p
            style={{
              fontSize: "16px",
              color: "rgba(255,255,255,0.45)",
              lineHeight: 1.8,
              margin: "0 0 48px",
              maxWidth: "440px",
            }}
          >
            Our custom design engine lets you craft tees that tell your unique
            story — from heritage patterns and street art to minimal type. Design,
            preview, and order in minutes.
          </p>

          {/* Feature list */}
          <div
            style={{ display: "flex", flexDirection: "column", gap: "24px", marginBottom: "56px" }}
          >
            {features.map(({ icon: Icon, title, desc }) => (
              <div
                key={title}
                style={{ display: "flex", alignItems: "flex-start", gap: "16px" }}
              >
                <div
                  style={{
                    width: "40px",
                    height: "40px",
                    borderRadius: "10px",
                    background: "rgba(79,142,247,0.08)",
                    border: "1px solid rgba(79,142,247,0.15)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                    color: "#4F8EF7",
                  }}
                >
                  <Icon size={18} strokeWidth={1.5} />
                </div>
                <div>
                  <div
                    style={{
                      fontSize: "14px",
                      fontWeight: 600,
                      color: "#FFFFFF",
                      marginBottom: "2px",
                    }}
                  >
                    {title}
                  </div>
                  <div style={{ fontSize: "13px", color: "rgba(255,255,255,0.4)" }}>
                    {desc}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button
            style={{
              background: hoveredCta
                ? "linear-gradient(135deg, #8B7CF8, #5A96F8)"
                : "linear-gradient(135deg, #7B6CF6, #4F8EF7)",
              border: "none",
              cursor: "pointer",
              color: "#FFFFFF",
              padding: "18px 40px",
              borderRadius: "8px",
              fontSize: "13px",
              fontWeight: 700,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              display: "inline-flex",
              alignItems: "center",
              gap: "12px",
              transition: "all 0.3s ease",
              boxShadow: hoveredCta
                ? "0 16px 48px rgba(123,108,246,0.5)"
                : "0 8px 32px rgba(123,108,246,0.35)",
              transform: hoveredCta ? "translateY(-2px)" : "translateY(0)",
              fontFamily: "'Inter', sans-serif",
            }}
            onMouseEnter={() => setHoveredCta(true)}
            onMouseLeave={() => setHoveredCta(false)}
          >
            Start Designing
            <ArrowRight size={16} strokeWidth={2.5} />
          </button>
        </div>

        {/* Right: Mockup Preview */}
        <div style={{ position: "relative" }}>
          {/* Glassmorphism card */}
          <div
            style={{
              background: "rgba(255,255,255,0.03)",
              backdropFilter: "blur(24px)",
              border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: "24px",
              padding: "40px",
              position: "relative",
              overflow: "hidden",
            }}
          >
            {/* Card header */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: "32px",
              }}
            >
              <div>
                <div
                  style={{
                    fontSize: "12px",
                    color: "rgba(255,255,255,0.35)",
                    marginBottom: "4px",
                    letterSpacing: "0.1em",
                    textTransform: "uppercase",
                  }}
                >
                  Design Studio
                </div>
                <div
                  style={{ fontSize: "16px", fontWeight: 600, color: "#FFFFFF" }}
                >
                  Custom Tee Builder
                </div>
              </div>
              <div
                style={{
                  background: "rgba(79,142,247,0.1)",
                  border: "1px solid rgba(79,142,247,0.2)",
                  borderRadius: "100px",
                  padding: "6px 14px",
                  fontSize: "11px",
                  color: "#4F8EF7",
                  fontWeight: 600,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                }}
              >
                Live Preview
              </div>
            </div>

            {/* Tee Preview */}
            <div
              style={{
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: "16px",
                height: "300px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                position: "relative",
                marginBottom: "28px",
                overflow: "hidden",
                transition: "all 0.4s ease",
              }}
            >
              {/* Simple t-shirt SVG shape */}
              <svg
                width="220"
                height="240"
                viewBox="0 0 220 240"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                style={{ filter: "drop-shadow(0 20px 40px rgba(0,0,0,0.4))", transition: "all 0.4s ease" }}
              >
                {/* T-shirt body */}
                <path
                  d="M60 20 L30 10 L5 60 L40 75 L35 230 L185 230 L180 75 L215 60 L190 10 L160 20 C150 45 70 45 60 20Z"
                  fill={currentColor.hex}
                  stroke="rgba(255,255,255,0.1)"
                  strokeWidth="1"
                />
                {/* Collar */}
                <path
                  d="M80 20 Q110 50 140 20"
                  fill="none"
                  stroke="rgba(255,255,255,0.15)"
                  strokeWidth="2"
                />
              </svg>

              {/* Design text overlay on tee */}
              <div
                style={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -20%)",
                  textAlign: "center",
                  pointerEvents: "none",
                }}
              >
                <div
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "14px",
                    fontWeight: 700,
                    color:
                      currentColor.hex === "#F5F0E8"
                        ? "#1C1C1C"
                        : "rgba(255,255,255,0.85)",
                    letterSpacing: "0.08em",
                    textTransform: "uppercase",
                    lineHeight: 1.3,
                  }}
                >
                  Rupkala
                </div>
                <div
                  style={{
                    width: "40px",
                    height: "1px",
                    background:
                      currentColor.hex === "#F5F0E8"
                        ? "rgba(28,28,28,0.5)"
                        : "rgba(255,255,255,0.3)",
                    margin: "4px auto",
                  }}
                />
                <div
                  style={{
                    fontSize: "8px",
                    color:
                      currentColor.hex === "#F5F0E8"
                        ? "rgba(28,28,28,0.6)"
                        : "rgba(255,255,255,0.4)",
                    letterSpacing: "0.15em",
                    textTransform: "uppercase",
                  }}
                >
                  Your Design Here
                </div>
              </div>
            </div>

            {/* Color picker */}
            <div>
              <div
                style={{
                  fontSize: "11px",
                  color: "rgba(255,255,255,0.35)",
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  marginBottom: "12px",
                }}
              >
                Color — {currentColor.name}
              </div>
              <div style={{ display: "flex", gap: "12px" }}>
                {teeColors.map((color, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedColor(i)}
                    style={{
                      width: "36px",
                      height: "36px",
                      borderRadius: "50%",
                      backgroundColor: color.hex,
                      border:
                        selectedColor === i
                          ? "2px solid #4F8EF7"
                          : "2px solid rgba(255,255,255,0.1)",
                      cursor: "pointer",
                      transition: "all 0.2s ease",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      transform: selectedColor === i ? "scale(1.15)" : "scale(1)",
                    }}
                  >
                    {selectedColor === i && (
                      <Check
                        size={14}
                        strokeWidth={2.5}
                        color={
                          color.hex === "#F5F0E8" ? "#1C1C1C" : "#FFFFFF"
                        }
                      />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Bottom row */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginTop: "28px",
                paddingTop: "24px",
                borderTop: "1px solid rgba(255,255,255,0.05)",
              }}
            >
              <div style={{ fontSize: "13px", color: "rgba(255,255,255,0.4)" }}>
                Est. Price
              </div>
              <div
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "22px",
                  fontWeight: 700,
                  color: "#FFFFFF",
                }}
              >
                ₹1,499
              </div>
            </div>
          </div>

          {/* Floating elements */}
          <div
            style={{
              position: "absolute",
              top: "-20px",
              right: "-20px",
              background: "rgba(79,142,247,0.08)",
              border: "1px solid rgba(79,142,247,0.15)",
              borderRadius: "12px",
              padding: "12px 16px",
              fontSize: "12px",
              color: "#4F8EF7",
              fontWeight: 600,
            }}
          >
            ✨ 500+ designs made today
          </div>
        </div>
      </div>
    </section>
  );
}
