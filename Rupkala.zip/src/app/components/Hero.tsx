import { ArrowRight, Play } from "lucide-react";
import { useState } from "react";

const HERO_IMAGE =
  "https://images.unsplash.com/photo-1581655353564-df123a1eb820?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsJTIwd2hpdGUlMjB0c2hpcnQlMjBtb2RlbCUyMGZhc2hpb24lMjBlZGl0b3JpYWx8ZW58MXx8fHwxNzcxOTMzMTcyfDA&ixlib=rb-4.1.0&q=80&w=1080";

export function Hero() {
  const [hoverDesign, setHoverDesign] = useState(false);
  const [hoverExplore, setHoverExplore] = useState(false);

  return (
    <section
      style={{
        minHeight: "100vh",
        backgroundColor: "#0C0C0C",
        position: "relative",
        overflow: "hidden",
        fontFamily: "'Inter', sans-serif",
        display: "flex",
        alignItems: "stretch",
      }}
    >
      {/* Background abstract elements */}
      <div
        style={{
          position: "absolute",
          top: "-200px",
          left: "-200px",
          width: "600px",
          height: "600px",
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(79,142,247,0.08) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "absolute",
          bottom: "-100px",
          right: "30%",
          width: "400px",
          height: "400px",
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(123,108,246,0.07) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      {/* Subtle grid overlay */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `
            linear-gradient(rgba(255,255,255,0.012) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.012) 1px, transparent 1px)
          `,
          backgroundSize: "64px 64px",
          pointerEvents: "none",
        }}
      />

      <div
        style={{
          maxWidth: "1440px",
          margin: "0 auto",
          padding: "0 48px",
          width: "100%",
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          alignItems: "center",
          gap: "48px",
          paddingTop: "80px",
        }}
        className="flex-col lg:grid"
      >
        {/* Left Content */}
        <div style={{ position: "relative", zIndex: 2 }}>
          {/* Tag */}
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              background: "rgba(79,142,247,0.08)",
              border: "1px solid rgba(79,142,247,0.2)",
              borderRadius: "100px",
              padding: "6px 16px",
              marginBottom: "40px",
            }}
          >
            <span
              style={{
                width: "6px",
                height: "6px",
                borderRadius: "50%",
                backgroundColor: "#4F8EF7",
                display: "inline-block",
                animation: "pulse 2s infinite",
              }}
            />
            <span
              style={{
                fontSize: "11px",
                color: "#4F8EF7",
                fontWeight: 600,
                letterSpacing: "0.15em",
                textTransform: "uppercase",
              }}
            >
              New Collection — 2025
            </span>
          </div>

          {/* Headline */}
          <h1
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(56px, 6vw, 88px)",
              fontWeight: 800,
              color: "#FFFFFF",
              lineHeight: 1.05,
              margin: "0 0 24px",
              letterSpacing: "-0.02em",
            }}
          >Wear Your<br /><span
              style={{
                background: "linear-gradient(135deg, #4F8EF7 0%, #7B6CF6 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
                fontStyle: "italic",
              }}
            >Story.</span></h1>

          {/* Subtext */}
          <p
            style={{
              fontSize: "17px",
              color: "rgba(255,255,255,0.5)",
              lineHeight: 1.75,
              margin: "0 0 48px",
              maxWidth: "440px",
              fontWeight: 400,
            }}
          >
            Every thread tells a tale. Create custom t-shirts that express your
            identity, your culture, your art — made to order, made for you.
          </p>

          {/* CTAs */}
          <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
            <button
              style={{
                background: hoverDesign
                  ? "linear-gradient(135deg, #5A96F8, #8B7CF8)"
                  : "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
                border: "none",
                cursor: "pointer",
                color: "#FFFFFF",
                padding: "16px 36px",
                borderRadius: "6px",
                fontSize: "13px",
                fontWeight: 600,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                transition: "all 0.3s ease",
                boxShadow: hoverDesign
                  ? "0 12px 40px rgba(79,142,247,0.5)"
                  : "0 6px 24px rgba(79,142,247,0.35)",
                transform: hoverDesign ? "translateY(-2px)" : "translateY(0)",
                fontFamily: "'Inter', sans-serif",
              }}
              onMouseEnter={() => setHoverDesign(true)}
              onMouseLeave={() => setHoverDesign(false)}
            >
              Design Your Tee
              <ArrowRight size={16} strokeWidth={2} />
            </button>

            <button
              style={{
                background: "transparent",
                border: hoverExplore
                  ? "1px solid rgba(255,255,255,0.5)"
                  : "1px solid rgba(255,255,255,0.2)",
                cursor: "pointer",
                color: hoverExplore
                  ? "#FFFFFF"
                  : "rgba(255,255,255,0.7)",
                padding: "16px 36px",
                borderRadius: "6px",
                fontSize: "13px",
                fontWeight: 600,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                transition: "all 0.3s ease",
                transform: hoverExplore ? "translateY(-2px)" : "translateY(0)",
                fontFamily: "'Inter', sans-serif",
              }}
              onMouseEnter={() => setHoverExplore(true)}
              onMouseLeave={() => setHoverExplore(false)}
            >
              Explore Collection
            </button>
          </div>

          {/* Stats row */}
          <div
            style={{
              display: "flex",
              gap: "40px",
              marginTop: "72px",
              paddingTop: "40px",
              borderTop: "1px solid rgba(255,255,255,0.06)",
            }}
          >
            {[
              { num: "12K+", label: "Happy Customers" },
              { num: "500+", label: "Custom Designs" },
              { num: "4.9★", label: "Average Rating" },
            ].map((stat) => (
              <div key={stat.label}>
                <div
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "28px",
                    fontWeight: 700,
                    color: "#FFFFFF",
                    lineHeight: 1.2,
                  }}
                >
                  {stat.num}
                </div>
                <div
                  style={{
                    fontSize: "12px",
                    color: "rgba(255,255,255,0.4)",
                    marginTop: "4px",
                    letterSpacing: "0.05em",
                  }}
                >
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right — Hero Image */}
        <div
          style={{
            position: "relative",
            height: "100vh",
            minHeight: "600px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {/* Glow behind image */}
          <div
            style={{
              position: "absolute",
              width: "70%",
              height: "70%",
              background:
                "radial-gradient(ellipse, rgba(79,142,247,0.15) 0%, transparent 70%)",
              borderRadius: "50%",
              zIndex: 0,
            }}
          />

          {/* Decorative ring */}
          <div
            style={{
              position: "absolute",
              width: "520px",
              height: "520px",
              border: "1px solid rgba(255,255,255,0.04)",
              borderRadius: "50%",
              zIndex: 0,
            }}
          />
          <div
            style={{
              position: "absolute",
              width: "420px",
              height: "420px",
              border: "1px solid rgba(79,142,247,0.08)",
              borderRadius: "50%",
              zIndex: 0,
            }}
          />

          {/* Main image */}
          <div
            style={{
              position: "relative",
              zIndex: 1,
              width: "380px",
              height: "520px",
              borderRadius: "200px 200px 16px 16px",
              overflow: "hidden",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <img
              src={HERO_IMAGE}
              alt="Rupkala Model"
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
                objectPosition: "center top",
                filter: "contrast(1.05) brightness(0.95)",
              }}
            />
            {/* gradient overlay at bottom */}
            <div
              style={{
                position: "absolute",
                bottom: 0,
                left: 0,
                right: 0,
                height: "200px",
                background:
                  "linear-gradient(to top, #0C0C0C 0%, transparent 100%)",
              }}
            />
          </div>

          {/* Floating tag — top right */}
          <div
            style={{
              position: "absolute",
              top: "18%",
              right: "4%",
              background: "rgba(255,255,255,0.04)",
              backdropFilter: "blur(16px)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: "12px",
              padding: "12px 18px",
              zIndex: 3,
            }}
          >
            <div
              style={{
                fontSize: "11px",
                color: "rgba(255,255,255,0.4)",
                letterSpacing: "0.1em",
                textTransform: "uppercase",
                marginBottom: "4px",
              }}
            >
              Material
            </div>
            <div
              style={{
                fontSize: "13px",
                color: "#FFFFFF",
                fontWeight: 600,
              }}
            >
              100% Organic Cotton
            </div>
          </div>

          {/* Floating tag — bottom left */}
          <div
            style={{
              position: "absolute",
              bottom: "22%",
              left: "2%",
              background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
              borderRadius: "12px",
              padding: "14px 20px",
              zIndex: 3,
              minWidth: "160px",
            }}
          >
            <div
              style={{
                fontSize: "11px",
                color: "rgba(255,255,255,0.7)",
                letterSpacing: "0.1em",
                textTransform: "uppercase",
                marginBottom: "2px",
              }}
            >
              Starting at
            </div>
            <div
              style={{
                fontSize: "22px",
                color: "#FFFFFF",
                fontWeight: 700,
                fontFamily: "'Playfair Display', serif",
              }}
            >
              ₹599
            </div>
          </div>

          {/* Play video CTA */}
          <button
            style={{
              position: "absolute",
              bottom: "12%",
              right: "6%",
              background: "rgba(255,255,255,0.06)",
              backdropFilter: "blur(12px)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "50%",
              width: "56px",
              height: "56px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: "#FFFFFF",
              transition: "all 0.3s ease",
              zIndex: 3,
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background =
                "rgba(79,142,247,0.2)";
              (e.currentTarget as HTMLElement).style.borderColor =
                "rgba(79,142,247,0.4)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background =
                "rgba(255,255,255,0.06)";
              (e.currentTarget as HTMLElement).style.borderColor =
                "rgba(255,255,255,0.1)";
            }}
          >
            <Play size={18} fill="currentColor" strokeWidth={0} />
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        style={{
          position: "absolute",
          bottom: "40px",
          left: "50%",
          transform: "translateX(-50%)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "8px",
          zIndex: 2,
        }}
      >
        <span
          style={{
            fontSize: "10px",
            color: "rgba(255,255,255,0.3)",
            letterSpacing: "0.2em",
            textTransform: "uppercase",
          }}
        >
          Scroll
        </span>
        <div
          style={{
            width: "1px",
            height: "48px",
            background:
              "linear-gradient(to bottom, rgba(255,255,255,0.3), transparent)",
            animation: "scrollPulse 2s ease-in-out infinite",
          }}
        />
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        @keyframes scrollPulse {
          0%, 100% { opacity: 0.6; transform: scaleY(1); }
          50% { opacity: 1; transform: scaleY(0.8); }
        }
      `}</style>
    </section>
  );
}
