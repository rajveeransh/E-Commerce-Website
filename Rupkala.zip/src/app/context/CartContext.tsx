import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import { projectId, publicAnonKey } from "/utils/supabase/info";

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-40f0d309`;

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  image: string;
  color: string;
  colorName: string;
  size: string;
  quantity: number;
}

interface CartContextValue {
  items: CartItem[];
  isOpen: boolean;
  isLoading: boolean;
  sessionId: string;
  itemCount: number;
  subtotal: number;
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  addToCart: (item: Omit<CartItem, "quantity"> & { quantity?: number }) => Promise<void>;
  removeFromCart: (productId: string, color: string, size: string) => Promise<void>;
  updateQuantity: (productId: string, color: string, size: string, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
}

const CartContext = createContext<CartContextValue | null>(null);

function getOrCreateSessionId(): string {
  let id = localStorage.getItem("rupkala_session_id");
  if (!id) {
    id = `sess_${Date.now()}_${Math.random().toString(36).substr(2, 12)}`;
    localStorage.setItem("rupkala_session_id", id);
  }
  return id;
}

async function apiFetch(path: string, options: RequestInit = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${publicAnonKey}`,
      ...options.headers,
    },
  });
  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.error || `API error ${response.status}`);
  }
  return data;
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId] = useState(() => getOrCreateSessionId());

  // Load cart from backend on mount
  useEffect(() => {
    const loadCart = async () => {
      try {
        const data = await apiFetch(`/cart/${sessionId}`);
        setItems(data.data?.items || []);
      } catch (err) {
        console.log("Failed to load cart from backend:", err);
      }
    };
    loadCart();
  }, [sessionId]);

  const openCart = useCallback(() => setIsOpen(true), []);
  const closeCart = useCallback(() => setIsOpen(false), []);
  const toggleCart = useCallback(() => setIsOpen((v) => !v), []);

  const addToCart = useCallback(
    async (item: Omit<CartItem, "quantity"> & { quantity?: number }) => {
      const quantity = item.quantity ?? 1;
      setIsLoading(true);

      // Optimistic update
      setItems((prev) => {
        const existingIdx = prev.findIndex(
          (i) => i.productId === item.productId && i.color === item.color && i.size === item.size
        );
        if (existingIdx >= 0) {
          const updated = [...prev];
          updated[existingIdx] = { ...updated[existingIdx], quantity: updated[existingIdx].quantity + quantity };
          return updated;
        }
        return [...prev, { ...item, quantity }];
      });

      try {
        const data = await apiFetch(`/cart/${sessionId}/add`, {
          method: "POST",
          body: JSON.stringify({ ...item, quantity }),
        });
        setItems(data.data?.items || []);
      } catch (err) {
        console.log("Failed to sync cart add to backend:", err);
      } finally {
        setIsLoading(false);
      }
    },
    [sessionId]
  );

  const removeFromCart = useCallback(
    async (productId: string, color: string, size: string) => {
      setIsLoading(true);
      // Optimistic update
      setItems((prev) =>
        prev.filter((i) => !(i.productId === productId && i.color === color && i.size === size))
      );
      try {
        const data = await apiFetch(`/cart/${sessionId}/item`, {
          method: "DELETE",
          body: JSON.stringify({ productId, color, size }),
        });
        setItems(data.data?.items || []);
      } catch (err) {
        console.log("Failed to sync cart remove to backend:", err);
      } finally {
        setIsLoading(false);
      }
    },
    [sessionId]
  );

  const updateQuantity = useCallback(
    async (productId: string, color: string, size: string, quantity: number) => {
      setIsLoading(true);
      // Optimistic update
      if (quantity <= 0) {
        setItems((prev) =>
          prev.filter((i) => !(i.productId === productId && i.color === color && i.size === size))
        );
      } else {
        setItems((prev) =>
          prev.map((i) =>
            i.productId === productId && i.color === color && i.size === size ? { ...i, quantity } : i
          )
        );
      }
      try {
        const data = await apiFetch(`/cart/${sessionId}/item`, {
          method: "PUT",
          body: JSON.stringify({ productId, color, size, quantity }),
        });
        setItems(data.data?.items || []);
      } catch (err) {
        console.log("Failed to sync quantity update to backend:", err);
      } finally {
        setIsLoading(false);
      }
    },
    [sessionId]
  );

  const clearCart = useCallback(async () => {
    setIsLoading(true);
    setItems([]);
    try {
      await apiFetch(`/cart/${sessionId}`, { method: "DELETE" });
    } catch (err) {
      console.log("Failed to clear cart on backend:", err);
    } finally {
      setIsLoading(false);
    }
  }, [sessionId]);

  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);
  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        isOpen,
        isLoading,
        sessionId,
        itemCount,
        subtotal,
        openCart,
        closeCart,
        toggleCart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside <CartProvider>");
  return ctx;
}
