import { useEffect, useState } from "react";
import {
  CheckCircle,
  Package,
  Truck,
  ArrowRight,
  Copy,
  Check,
  Calendar,
} from "lucide-react";
import { Link, useSearchParams, useLocation } from "react-router";
import { projectId, publicAnonKey } from "/utils/supabase/info";
import { motion } from "motion/react";
import { Footer } from "../components/Footer";

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-40f0d309`;

interface Order {
  id: string;
  items: any[];
  customerInfo: { name: string; email: string; phone: string };
  shippingAddress: { address: string; city: string; state: string; pincode: string };
  subtotal: number;
  shippingFee: number;
  total: number;
  status: string;
  paymentMethod: string;
  createdAt: string;
  estimatedDelivery: string;
}

const STEPS = [
  { icon: CheckCircle, label: "Order Confirmed", color: "#22C55E" },
  { icon: Package, label: "Processing", color: "#4F8EF7" },
  { icon: Truck, label: "Out for Delivery", color: "#7B6CF6" },
];

export function OrderSuccess() {
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const orderId = searchParams.get("orderId");

  const [order, setOrder] = useState<Order | null>(
    (location.state as any)?.order || null,
  );
  const [isLoading, setIsLoading] = useState(!order);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    if (!order && orderId) {
      const fetchOrder = async () => {
        try {
          const res = await fetch(`${API_BASE}/orders/${orderId}`, {
            headers: { Authorization: `Bearer ${publicAnonKey}` },
          });
          const data = await res.json();
          if (data.success) setOrder(data.data);
        } catch (err) {
          console.log("Error fetching order:", err);
        } finally {
          setIsLoading(false);
        }
      };
      fetchOrder();
    }
  }, [orderId]);

  const copyOrderId = async () => {
    if (!orderId) return;
    await navigator.clipboard.writeText(orderId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatDate = (iso: string) => {
    return new Date(iso).toLocaleDateString("en-IN", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  if (isLoading) {
    return (
      <div
        style={{
          minHeight: "100vh",
          backgroundColor: "#0C0C0C",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontFamily: "'Inter', sans-serif",
        }}
      >
        <div
          style={{
            width: "40px",
            height: "40px",
            border: "3px solid rgba(79,142,247,0.2)",
            borderTop: "3px solid #4F8EF7",
            borderRadius: "50%",
            animation: "spin 0.7s linear infinite",
          }}
        />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return (
    <>
      <div
        style={{
          minHeight: "100vh",
          backgroundColor: "#0C0C0C",
          paddingTop: "80px",
          fontFamily: "'Inter', sans-serif",
        }}
      >
        <div
          style={{
            maxWidth: "900px",
            margin: "0 auto",
            padding: "60px 48px 120px",
          }}
        >
          {/* Success Header */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, type: "spring", stiffness: 200 }}
            style={{ textAlign: "center", marginBottom: "64px" }}
          >
            {/* Animated checkmark */}
            <div
              style={{
                width: "96px",
                height: "96px",
                borderRadius: "50%",
                background:
                  "radial-gradient(circle, rgba(34,197,94,0.2) 0%, transparent 70%)",
                border: "2px solid rgba(34,197,94,0.3)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "0 auto 28px",
                animation: "pulse-success 2s ease-in-out infinite",
              }}
            >
              <CheckCircle size={48} color="#22C55E" strokeWidth={1.5} />
            </div>

            <p
              style={{
                fontSize: "11px",
                color: "#22C55E",
                fontWeight: 600,
                letterSpacing: "0.2em",
                textTransform: "uppercase",
                marginBottom: "16px",
              }}
            >
              Order Confirmed
            </p>

            <h1
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(36px, 5vw, 56px)",
                fontWeight: 800,
                color: "#FFFFFF",
                margin: "0 0 16px",
                lineHeight: 1.1,
                letterSpacing: "-0.02em",
              }}
            >
              Your story is{" "}
              <span
                style={{
                  background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                  fontStyle: "italic",
                }}
              >
                on its way.
              </span>
            </h1>

            <p
              style={{
                fontSize: "16px",
                color: "rgba(255,255,255,0.45)",
                margin: "0 auto",
                maxWidth: "500px",
                lineHeight: 1.7,
              }}
            >
              Thank you for choosing Rupkala. Your custom tee is being crafted
              with care and will arrive at your doorstep soon.
            </p>

            {/* Order ID */}
            {orderId && (
              <div
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "12px",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "100px",
                  padding: "10px 20px",
                  marginTop: "28px",
                  cursor: "pointer",
                }}
                onClick={copyOrderId}
              >
                <span
                  style={{
                    fontSize: "12px",
                    color: "rgba(255,255,255,0.4)",
                    letterSpacing: "0.08em",
                  }}
                >
                  Order ID:
                </span>
                <span
                  style={{
                    fontSize: "13px",
                    fontWeight: 700,
                    color: "#FFFFFF",
                    fontFamily: "monospace",
                    letterSpacing: "0.05em",
                  }}
                >
                  {orderId}
                </span>
                <button
                  style={{
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                    color: copied ? "#22C55E" : "rgba(255,255,255,0.4)",
                    display: "flex",
                    padding: 0,
                    transition: "color 0.2s ease",
                  }}
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                </button>
              </div>
            )}
          </motion.div>

          {/* Progress Tracker */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            style={{
              background: "rgba(255,255,255,0.02)",
              border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: "20px",
              padding: "36px",
              marginBottom: "24px",
            }}
          >
            <h3
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "20px",
                fontWeight: 700,
                color: "#FFFFFF",
                margin: "0 0 32px",
              }}
            >
              Order Status
            </h3>

            <div
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: "0",
                position: "relative",
              }}
            >
              {STEPS.map((step, i) => {
                const Icon = step.icon;
                const isActive = i === 0;
                const isPast = false;

                return (
                  <div
                    key={step.label}
                    style={{
                      flex: 1,
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      position: "relative",
                    }}
                  >
                    {/* Connector line */}
                    {i < STEPS.length - 1 && (
                      <div
                        style={{
                          position: "absolute",
                          top: "24px",
                          left: "50%",
                          right: "-50%",
                          height: "2px",
                          background: isActive
                            ? "rgba(255,255,255,0.08)"
                            : "rgba(255,255,255,0.08)",
                          zIndex: 0,
                        }}
                      />
                    )}

                    <div
                      style={{
                        width: "48px",
                        height: "48px",
                        borderRadius: "50%",
                        background: isActive
                          ? `rgba(34,197,94,0.15)`
                          : "rgba(255,255,255,0.04)",
                        border: `2px solid ${
                          isActive ? step.color : "rgba(255,255,255,0.1)"
                        }`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        position: "relative",
                        zIndex: 1,
                        marginBottom: "14px",
                        transition: "all 0.3s ease",
                      }}
                    >
                      <Icon
                        size={20}
                        color={isActive ? step.color : "rgba(255,255,255,0.25)"}
                        strokeWidth={1.5}
                      />
                    </div>
                    <span
                      style={{
                        fontSize: "12px",
                        fontWeight: isActive ? 600 : 400,
                        color: isActive ? "#FFFFFF" : "rgba(255,255,255,0.35)",
                        textAlign: "center",
                        letterSpacing: "0.03em",
                      }}
                    >
                      {step.label}
                    </span>
                    {isActive && (
                      <span
                        style={{
                          fontSize: "10px",
                          color: "#22C55E",
                          marginTop: "4px",
                          fontWeight: 600,
                        }}
                      >
                        ● Current
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Estimated delivery */}
            {order?.estimatedDelivery && (
              <div
                style={{
                  marginTop: "32px",
                  padding: "16px 20px",
                  background: "rgba(79,142,247,0.06)",
                  border: "1px solid rgba(79,142,247,0.15)",
                  borderRadius: "12px",
                  display: "flex",
                  alignItems: "center",
                  gap: "12px",
                }}
              >
                <Calendar size={18} color="#4F8EF7" strokeWidth={1.5} />
                <div>
                  <div
                    style={{
                      fontSize: "12px",
                      color: "rgba(255,255,255,0.5)",
                      marginBottom: "2px",
                    }}
                  >
                    Estimated Delivery
                  </div>
                  <div
                    style={{
                      fontSize: "14px",
                      fontWeight: 600,
                      color: "#FFFFFF",
                    }}
                  >
                    {formatDate(order.estimatedDelivery)}
                  </div>
                </div>
              </div>
            )}
          </motion.div>

          {/* Order Details */}
          {order && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "24px",
                marginBottom: "24px",
              }}
            >
              {/* Items */}
              <div
                style={{
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: "20px",
                  padding: "28px",
                  gridColumn: "span 2",
                }}
              >
                <h3
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "18px",
                    fontWeight: 700,
                    color: "#FFFFFF",
                    margin: "0 0 20px",
                  }}
                >
                  Items Ordered
                </h3>
                <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                  {order.items.map((item: any, i: number) => (
                    <div
                      key={i}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "16px",
                        padding: "14px",
                        background: "rgba(255,255,255,0.02)",
                        borderRadius: "12px",
                        border: "1px solid rgba(255,255,255,0.04)",
                      }}
                    >
                      <div
                        style={{
                          width: "56px",
                          height: "68px",
                          borderRadius: "8px",
                          overflow: "hidden",
                          flexShrink: 0,
                          background: "#1A1A1A",
                        }}
                      >
                        {item.image && (
                          <img
                            src={item.image}
                            alt={item.name}
                            style={{
                              width: "100%",
                              height: "100%",
                              objectFit: "cover",
                            }}
                          />
                        )}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div
                          style={{
                            fontFamily: "'Playfair Display', serif",
                            fontSize: "15px",
                            fontWeight: 600,
                            color: "#FFFFFF",
                            marginBottom: "4px",
                          }}
                        >
                          {item.name}
                        </div>
                        <div
                          style={{
                            fontSize: "12px",
                            color: "rgba(255,255,255,0.4)",
                          }}
                        >
                          {item.colorName || item.color} · Size {item.size} ·
                          Qty {item.quantity}
                        </div>
                      </div>
                      <div
                        style={{
                          fontSize: "15px",
                          fontWeight: 700,
                          color: "#FFFFFF",
                          flexShrink: 0,
                        }}
                      >
                        ₹{(item.price * item.quantity).toLocaleString("en-IN")}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Price breakdown */}
                <div
                  style={{
                    marginTop: "20px",
                    paddingTop: "20px",
                    borderTop: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  {[
                    {
                      label: "Subtotal",
                      value: `₹${order.subtotal.toLocaleString("en-IN")}`,
                    },
                    {
                      label: "Shipping",
                      value:
                        order.shippingFee === 0
                          ? "FREE"
                          : `₹${order.shippingFee}`,
                      valueColor: order.shippingFee === 0 ? "#22C55E" : undefined,
                    },
                  ].map(({ label, value, valueColor }) => (
                    <div
                      key={label}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        marginBottom: "8px",
                        fontSize: "13px",
                      }}
                    >
                      <span style={{ color: "rgba(255,255,255,0.45)" }}>
                        {label}
                      </span>
                      <span
                        style={{
                          color: valueColor || "rgba(255,255,255,0.75)",
                          fontWeight: 500,
                        }}
                      >
                        {value}
                      </span>
                    </div>
                  ))}
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      marginTop: "12px",
                      paddingTop: "12px",
                      borderTop: "1px solid rgba(255,255,255,0.06)",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "15px",
                        fontWeight: 600,
                        color: "#FFFFFF",
                      }}
                    >
                      Total Paid
                    </span>
                    <span
                      style={{
                        fontFamily: "'Playfair Display', serif",
                        fontSize: "22px",
                        fontWeight: 800,
                        color: "#FFFFFF",
                      }}
                    >
                      ₹{order.total.toLocaleString("en-IN")}
                    </span>
                  </div>
                </div>
              </div>

              {/* Delivery Info */}
              <div
                style={{
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: "20px",
                  padding: "28px",
                }}
              >
                <h3
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "18px",
                    fontWeight: 700,
                    color: "#FFFFFF",
                    margin: "0 0 20px",
                  }}
                >
                  Deliver To
                </h3>
                <div style={{ fontSize: "14px", lineHeight: 1.8, color: "rgba(255,255,255,0.6)" }}>
                  <div style={{ fontWeight: 600, color: "#FFFFFF", marginBottom: "4px" }}>
                    {order.customerInfo.name}
                  </div>
                  <div>{order.shippingAddress.address}</div>
                  <div>
                    {order.shippingAddress.city},{" "}
                    {order.shippingAddress.state} —{" "}
                    {order.shippingAddress.pincode}
                  </div>
                  <div style={{ marginTop: "8px", color: "rgba(255,255,255,0.45)" }}>
                    {order.customerInfo.email}
                  </div>
                  <div style={{ color: "rgba(255,255,255,0.45)" }}>
                    {order.customerInfo.phone}
                  </div>
                </div>
              </div>

              {/* Payment Info */}
              <div
                style={{
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: "20px",
                  padding: "28px",
                }}
              >
                <h3
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "18px",
                    fontWeight: 700,
                    color: "#FFFFFF",
                    margin: "0 0 20px",
                  }}
                >
                  Payment
                </h3>
                <div style={{ fontSize: "14px", lineHeight: 2, color: "rgba(255,255,255,0.6)" }}>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span>Method</span>
                    <span style={{ color: "#FFFFFF", fontWeight: 600, textTransform: "uppercase" }}>
                      {order.paymentMethod === "cod"
                        ? "Cash on Delivery"
                        : order.paymentMethod === "upi"
                        ? "UPI"
                        : "Card"}
                    </span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span>Status</span>
                    <span
                      style={{
                        color: "#22C55E",
                        fontWeight: 600,
                        display: "flex",
                        alignItems: "center",
                        gap: "6px",
                      }}
                    >
                      <CheckCircle size={13} />
                      {order.paymentMethod === "cod" ? "Pay on Delivery" : "Confirmed"}
                    </span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span>Ordered</span>
                    <span style={{ color: "rgba(255,255,255,0.7)" }}>
                      {new Date(order.createdAt).toLocaleDateString("en-IN")}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            style={{
              display: "flex",
              gap: "16px",
              justifyContent: "center",
              flexWrap: "wrap",
              marginTop: "8px",
            }}
          >
            <Link
              to="/collection"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "10px",
                padding: "16px 32px",
                background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
                borderRadius: "10px",
                color: "#FFFFFF",
                textDecoration: "none",
                fontSize: "13px",
                fontWeight: 700,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                boxShadow: "0 8px 32px rgba(79,142,247,0.4)",
                transition: "all 0.3s ease",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.transform =
                  "translateY(-2px)";
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 12px 40px rgba(79,142,247,0.5)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 8px 32px rgba(79,142,247,0.4)";
              }}
            >
              Continue Shopping
              <ArrowRight size={16} />
            </Link>
            <Link
              to="/"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "10px",
                padding: "16px 32px",
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: "10px",
                color: "rgba(255,255,255,0.7)",
                textDecoration: "none",
                fontSize: "13px",
                fontWeight: 600,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                transition: "all 0.2s ease",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor =
                  "rgba(255,255,255,0.25)";
                (e.currentTarget as HTMLElement).style.color = "#FFFFFF";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor =
                  "rgba(255,255,255,0.1)";
                (e.currentTarget as HTMLElement).style.color =
                  "rgba(255,255,255,0.7)";
              }}
            >
              Back to Home
            </Link>
          </motion.div>
        </div>
      </div>

      <Footer />

      <style>{`
        @keyframes pulse-success {
          0%, 100% { box-shadow: 0 0 0 0 rgba(34,197,94,0.2); }
          50% { box-shadow: 0 0 0 16px rgba(34,197,94,0); }
        }
      `}</style>
    </>
  );
}
