import { useState, useEffect } from "react";
import { SlidersHorizontal, Search, Heart, Eye, ShoppingBag, ChevronDown, X } from "lucide-react";
import { Link, useSearchParams } from "react-router";
import { useCart } from "../context/CartContext";
import { projectId, publicAnonKey } from "/utils/supabase/info";
import { Footer } from "../components/Footer";
import { toast } from "sonner";

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-40f0d309`;

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice: number | null;
  tag: string;
  tagColor: string;
  image: string;
  colors: string[];
  colorNames: string[];
  sizes: string[];
  category: string;
  rating: number;
  reviewCount: number;
  gsm: number;
  fit: string;
  inStock: boolean;
}

const CATEGORIES = [
  { id: "all", label: "All Products" },
  { id: "classic", label: "Classic" },
  { id: "streetwear", label: "Streetwear" },
  { id: "limited", label: "Limited" },
  { id: "custom", label: "Custom" },
];

const SORT_OPTIONS = [
  { value: "default", label: "Featured" },
  { value: "price_asc", label: "Price: Low to High" },
  { value: "price_desc", label: "Price: High to Low" },
  { value: "rating", label: "Top Rated" },
];

function ProductCard({ product }: { product: Product }) {
  const [hovered, setHovered] = useState(false);
  const [liked, setLiked] = useState(false);
  const [selectedColor, setSelectedColor] = useState(0);
  const { addToCart, openCart } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart({
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      color: product.colors[selectedColor],
      colorName: product.colorNames?.[selectedColor] || product.colors[selectedColor],
      size: product.sizes[Math.floor(product.sizes.length / 2)], // default middle size
    });
    toast.success(`${product.name} added to cart!`, { duration: 2000 });
    openCart();
  };

  const discount = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : null;

  return (
    <Link to={`/product/${product.id}`} style={{ textDecoration: "none", display: "block" }}>
      <div
        style={{
          background: "#141414",
          borderRadius: "16px",
          overflow: "hidden",
          border: hovered
            ? "1px solid rgba(79,142,247,0.25)"
            : "1px solid rgba(255,255,255,0.06)",
          transition: "all 0.4s ease",
          transform: hovered ? "translateY(-8px)" : "translateY(0)",
          boxShadow: hovered
            ? "0 32px 64px rgba(0,0,0,0.5), 0 0 0 1px rgba(79,142,247,0.1)"
            : "0 8px 24px rgba(0,0,0,0.2)",
          cursor: "pointer",
          fontFamily: "'Inter', sans-serif",
        }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
      >
        {/* Image Container */}
        <div style={{ position: "relative", overflow: "hidden", height: "300px" }}>
          <img
            src={product.image}
            alt={product.name}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              transition: "transform 0.6s ease",
              transform: hovered ? "scale(1.06)" : "scale(1)",
              filter: "brightness(0.92) contrast(1.05)",
            }}
          />
          <div
            style={{
              position: "absolute",
              inset: 0,
              background: "linear-gradient(to top, rgba(20,20,20,0.6) 0%, transparent 50%)",
            }}
          />

          {/* Tag */}
          <div
            style={{
              position: "absolute",
              top: "16px",
              left: "16px",
              background: product.tagColor,
              color: "#fff",
              fontSize: "10px",
              fontWeight: 700,
              letterSpacing: "0.12em",
              textTransform: "uppercase",
              padding: "4px 12px",
              borderRadius: "100px",
            }}
          >
            {product.tag}
          </div>

          {discount && (
            <div
              style={{
                position: "absolute",
                top: "16px",
                right: "16px",
                background: "#E63946",
                color: "#fff",
                fontSize: "10px",
                fontWeight: 700,
                padding: "4px 10px",
                borderRadius: "100px",
                opacity: hovered ? 0 : 1,
                transition: "opacity 0.3s ease",
              }}
            >
              -{discount}%
            </div>
          )}

          {/* Action buttons */}
          <div
            style={{
              position: "absolute",
              top: "12px",
              right: "12px",
              display: "flex",
              flexDirection: "column",
              gap: "8px",
              opacity: hovered ? 1 : 0,
              transform: hovered ? "translateX(0)" : "translateX(12px)",
              transition: "all 0.3s ease",
            }}
          >
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setLiked(!liked);
                toast(liked ? "Removed from wishlist" : "Added to wishlist!", { duration: 1500 });
              }}
              style={{
                width: "40px",
                height: "40px",
                borderRadius: "10px",
                background: "rgba(12,12,12,0.7)",
                backdropFilter: "blur(12px)",
                border: "1px solid rgba(255,255,255,0.1)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                color: liked ? "#E63946" : "rgba(255,255,255,0.7)",
                transition: "all 0.2s ease",
              }}
            >
              <Heart size={15} fill={liked ? "currentColor" : "none"} />
            </button>
            <Link
              to={`/product/${product.id}`}
              onClick={(e) => e.stopPropagation()}
              style={{
                width: "40px",
                height: "40px",
                borderRadius: "10px",
                background: "rgba(12,12,12,0.7)",
                backdropFilter: "blur(12px)",
                border: "1px solid rgba(255,255,255,0.1)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                color: "rgba(255,255,255,0.7)",
                textDecoration: "none",
              }}
            >
              <Eye size={15} />
            </Link>
          </div>

          {/* Color swatches on hover */}
          <div
            style={{
              position: "absolute",
              bottom: "16px",
              left: "16px",
              display: "flex",
              gap: "8px",
              opacity: hovered ? 1 : 0,
              transition: "opacity 0.3s ease",
            }}
          >
            {product.colors.map((color, i) => (
              <button
                key={i}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setSelectedColor(i);
                }}
                style={{
                  width: "20px",
                  height: "20px",
                  borderRadius: "50%",
                  backgroundColor: color,
                  border:
                    selectedColor === i
                      ? "2px solid #4F8EF7"
                      : "2px solid rgba(255,255,255,0.2)",
                  cursor: "pointer",
                  transition: "border-color 0.2s ease",
                  flexShrink: 0,
                }}
              />
            ))}
          </div>
        </div>

        {/* Card Body */}
        <div style={{ padding: "20px 20px 24px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: "6px" }}>
            <h3
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "16px",
                fontWeight: 600,
                color: "#FFFFFF",
                margin: 0,
                letterSpacing: "-0.01em",
                lineHeight: 1.3,
              }}
            >
              {product.name}
            </h3>
            <div style={{ display: "flex", alignItems: "center", gap: "4px", flexShrink: 0, marginLeft: "8px" }}>
              <span style={{ fontSize: "11px", color: "#F59E0B" }}>★</span>
              <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.5)" }}>
                {product.rating} ({product.reviewCount})
              </span>
            </div>
          </div>

          <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.35)", marginBottom: "14px" }}>
            {product.fit} · {product.gsm}GSM
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "10px",
              marginBottom: "16px",
            }}
          >
            <span style={{ fontSize: "18px", fontWeight: 700, color: "#FFFFFF" }}>
              ₹{product.price.toLocaleString("en-IN")}
            </span>
            {product.originalPrice && (
              <>
                <span
                  style={{
                    fontSize: "13px",
                    color: "rgba(255,255,255,0.3)",
                    textDecoration: "line-through",
                  }}
                >
                  ₹{product.originalPrice.toLocaleString("en-IN")}
                </span>
                <span style={{ fontSize: "11px", color: "#22C55E", fontWeight: 600 }}>
                  {discount}% off
                </span>
              </>
            )}
          </div>

          <button
            onClick={handleAddToCart}
            style={{
              width: "100%",
              padding: "13px 20px",
              borderRadius: "8px",
              background: hovered
                ? "linear-gradient(135deg, #4F8EF7, #7B6CF6)"
                : "rgba(255,255,255,0.06)",
              border: hovered ? "none" : "1px solid rgba(255,255,255,0.12)",
              color: "#FFFFFF",
              fontSize: "12px",
              fontWeight: 600,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              cursor: "pointer",
              transition: "all 0.3s ease",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
              fontFamily: "'Inter', sans-serif",
              boxShadow: hovered ? "0 6px 24px rgba(79,142,247,0.35)" : "none",
            }}
          >
            <ShoppingBag size={14} strokeWidth={1.8} />
            Add to Cart
          </button>
        </div>
      </div>
    </Link>
  );
}

export function Collection() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState("all");
  const [sortBy, setSortBy] = useState("default");
  const [sortOpen, setSortOpen] = useState(false);
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get("search") || "";

  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      try {
        let url = `${API_BASE}/products?`;
        if (activeCategory !== "all") url += `category=${activeCategory}&`;
        if (sortBy !== "default") url += `sort=${sortBy}&`;
        if (searchQuery) url += `search=${encodeURIComponent(searchQuery)}&`;

        const res = await fetch(url, {
          headers: { Authorization: `Bearer ${publicAnonKey}` },
        });
        const data = await res.json();
        if (data.success) setProducts(data.data);
      } catch (err) {
        console.log("Error fetching products:", err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchProducts();
  }, [activeCategory, sortBy, searchQuery]);

  return (
    <>
      {/* Page Hero */}
      <section
        style={{
          backgroundColor: "#0C0C0C",
          paddingTop: "140px",
          paddingBottom: "60px",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundImage: `
              linear-gradient(rgba(255,255,255,0.012) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255,255,255,0.012) 1px, transparent 1px)
            `,
            backgroundSize: "64px 64px",
            pointerEvents: "none",
          }}
        />
        <div style={{ maxWidth: "1440px", margin: "0 auto", padding: "0 48px", position: "relative" }}>
          <p
            style={{
              fontSize: "11px",
              color: "#4F8EF7",
              fontWeight: 600,
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              marginBottom: "16px",
              fontFamily: "'Inter', sans-serif",
            }}
          >
            {searchQuery ? `Search: "${searchQuery}"` : "Our Collection"}
          </p>
          <h1
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(40px, 5vw, 72px)",
              fontWeight: 800,
              color: "#FFFFFF",
              margin: "0 0 16px",
              letterSpacing: "-0.02em",
              lineHeight: 1.05,
            }}
          >
            {searchQuery ? "Search Results" : "Shop the Collection"}
          </h1>
          <p style={{ fontSize: "16px", color: "rgba(255,255,255,0.45)", fontFamily: "'Inter', sans-serif", margin: 0 }}>
            {products.length} {products.length === 1 ? "product" : "products"} ·{" "}
            Premium custom tees crafted with intention.
          </p>
        </div>
      </section>

      {/* Filters + Grid */}
      <section
        style={{
          backgroundColor: "#0C0C0C",
          padding: "48px 0 120px",
          fontFamily: "'Inter', sans-serif",
        }}
      >
        <div style={{ maxWidth: "1440px", margin: "0 auto", padding: "0 48px" }}>
          {/* Filter Bar */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: "40px",
              flexWrap: "wrap",
              gap: "16px",
            }}
          >
            {/* Category Pills */}
            <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  style={{
                    padding: "8px 18px",
                    borderRadius: "100px",
                    border: activeCategory === cat.id
                      ? "1px solid #4F8EF7"
                      : "1px solid rgba(255,255,255,0.1)",
                    background: activeCategory === cat.id
                      ? "rgba(79,142,247,0.15)"
                      : "rgba(255,255,255,0.04)",
                    color: activeCategory === cat.id ? "#4F8EF7" : "rgba(255,255,255,0.6)",
                    fontSize: "12px",
                    fontWeight: activeCategory === cat.id ? 700 : 500,
                    letterSpacing: "0.08em",
                    cursor: "pointer",
                    transition: "all 0.25s ease",
                    fontFamily: "'Inter', sans-serif",
                    textTransform: "uppercase",
                  }}
                >
                  {cat.label}
                </button>
              ))}

              {searchQuery && (
                <Link
                  to="/collection"
                  style={{
                    padding: "8px 18px",
                    borderRadius: "100px",
                    border: "1px solid rgba(230,57,70,0.3)",
                    background: "rgba(230,57,70,0.08)",
                    color: "#E63946",
                    fontSize: "12px",
                    fontWeight: 600,
                    letterSpacing: "0.08em",
                    cursor: "pointer",
                    textDecoration: "none",
                    display: "flex",
                    alignItems: "center",
                    gap: "6px",
                  }}
                >
                  <X size={12} /> Clear Search
                </Link>
              )}
            </div>

            {/* Sort Dropdown */}
            <div style={{ position: "relative" }}>
              <button
                onClick={() => setSortOpen((v) => !v)}
                style={{
                  padding: "10px 18px",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "8px",
                  color: "rgba(255,255,255,0.7)",
                  fontSize: "12px",
                  fontWeight: 500,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  fontFamily: "'Inter', sans-serif",
                  letterSpacing: "0.06em",
                }}
              >
                <SlidersHorizontal size={14} />
                {SORT_OPTIONS.find((s) => s.value === sortBy)?.label}
                <ChevronDown size={13} style={{ transition: "transform 0.2s", transform: sortOpen ? "rotate(180deg)" : "none" }} />
              </button>
              {sortOpen && (
                <div
                  style={{
                    position: "absolute",
                    top: "calc(100% + 8px)",
                    right: 0,
                    background: "#1A1A1A",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "12px",
                    overflow: "hidden",
                    minWidth: "200px",
                    boxShadow: "0 20px 40px rgba(0,0,0,0.4)",
                    zIndex: 10,
                  }}
                >
                  {SORT_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => { setSortBy(opt.value); setSortOpen(false); }}
                      style={{
                        display: "block",
                        width: "100%",
                        padding: "12px 16px",
                        background: sortBy === opt.value ? "rgba(79,142,247,0.1)" : "none",
                        border: "none",
                        color: sortBy === opt.value ? "#4F8EF7" : "rgba(255,255,255,0.7)",
                        fontSize: "13px",
                        fontWeight: sortBy === opt.value ? 600 : 400,
                        cursor: "pointer",
                        textAlign: "left",
                        borderBottom: "1px solid rgba(255,255,255,0.04)",
                        fontFamily: "'Inter', sans-serif",
                        transition: "all 0.2s ease",
                      }}
                      onMouseEnter={(e) => {
                        if (sortBy !== opt.value) {
                          (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.05)";
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (sortBy !== opt.value) {
                          (e.currentTarget as HTMLElement).style.background = "none";
                        }
                      }}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Product Grid */}
          {isLoading ? (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
                gap: "24px",
              }}
            >
              {Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  style={{
                    background: "#141414",
                    borderRadius: "16px",
                    height: "440px",
                    border: "1px solid rgba(255,255,255,0.06)",
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      height: "300px",
                      background: "linear-gradient(110deg, #1A1A1A 30%, #222 50%, #1A1A1A 70%)",
                      backgroundSize: "200% 100%",
                      animation: "shimmer 1.5s infinite",
                    }}
                  />
                  <div style={{ padding: "20px" }}>
                    <div style={{ height: "16px", background: "#1A1A1A", borderRadius: "4px", marginBottom: "12px" }} />
                    <div style={{ height: "24px", background: "#1A1A1A", borderRadius: "4px", width: "60%", marginBottom: "16px" }} />
                    <div style={{ height: "44px", background: "#1A1A1A", borderRadius: "8px" }} />
                  </div>
                </div>
              ))}
            </div>
          ) : products.length === 0 ? (
            <div style={{ textAlign: "center", padding: "80px 0" }}>
              <Search size={48} color="rgba(255,255,255,0.1)" style={{ marginBottom: "24px" }} />
              <h3
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "28px",
                  fontWeight: 700,
                  color: "#FFFFFF",
                  margin: "0 0 12px",
                }}
              >
                No products found
              </h3>
              <p style={{ fontSize: "15px", color: "rgba(255,255,255,0.4)", margin: 0 }}>
                Try a different category or search term.
              </p>
            </div>
          ) : (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
                gap: "24px",
              }}
            >
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
      <style>{`
        @keyframes shimmer {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
      `}</style>
    </>
  );
}
