import { useState } from "react";
import {
  ArrowLeft,
  Truck,
  Shield,
  CreditCard,
  Smartphone,
  Banknote,
  CheckCircle,
  Lock,
  ChevronRight,
} from "lucide-react";
import { Link, useNavigate } from "react-router";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import { projectId, publicAnonKey } from "/utils/supabase/info";
import { toast } from "sonner";
import { motion } from "motion/react";

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-40f0d309`;

const SHIPPING_THRESHOLD = 999;
const SHIPPING_FEE = 99;

type PaymentMethod = "upi" | "card" | "cod";

interface FormData {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  upiId?: string;
}

function InputField({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
  error = false,
  colSpan = 1,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  required?: boolean;
  error?: boolean;
  colSpan?: number;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div
      style={{
        gridColumn: colSpan > 1 ? `span ${colSpan}` : undefined,
      }}
    >
      <label
        style={{
          display: "block",
          fontSize: "11px",
          fontWeight: 600,
          color: error ? "#E63946" : "rgba(255,255,255,0.5)",
          letterSpacing: "0.1em",
          textTransform: "uppercase",
          marginBottom: "8px",
          fontFamily: "'Inter', sans-serif",
        }}
      >
        {label}
        {required && (
          <span style={{ color: "#E63946", marginLeft: "4px" }}>*</span>
        )}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={placeholder}
        required={required}
        style={{
          width: "100%",
          padding: "14px 16px",
          background: "rgba(255,255,255,0.04)",
          border: `1px solid ${
            error
              ? "rgba(230,57,70,0.5)"
              : focused
              ? "rgba(79,142,247,0.5)"
              : "rgba(255,255,255,0.1)"
          }`,
          borderRadius: "10px",
          color: "#FFFFFF",
          fontSize: "14px",
          outline: "none",
          fontFamily: "'Inter', sans-serif",
          transition: "border-color 0.2s ease",
          boxSizing: "border-box",
        }}
      />
    </div>
  );
}

export function Checkout() {
  const navigate = useNavigate();
  const { items, subtotal, sessionId, clearCart } = useCart();
  const { user, session } = useAuth();

  const shipping = subtotal >= SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  const total = subtotal + shipping;

  const [step, setStep] = useState<"details" | "payment">("details");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("upi");
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);

  const [form, setForm] = useState<FormData>({
    name: (user?.user_metadata?.name as string) || "",
    email: user?.email || "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    upiId: "",
  });
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, boolean>>>(
    {},
  );

  const updateField = (key: keyof FormData) => (val: string) => {
    setForm((f) => ({ ...f, [key]: val }));
    setErrors((e) => ({ ...e, [key]: false }));
  };

  const validateStep1 = () => {
    const newErrors: typeof errors = {};
    if (!form.name.trim()) newErrors.name = true;
    if (!form.email.trim() || !form.email.includes("@")) newErrors.email = true;
    if (!form.phone.trim() || form.phone.length < 10) newErrors.phone = true;
    if (!form.address.trim()) newErrors.address = true;
    if (!form.city.trim()) newErrors.city = true;
    if (!form.state.trim()) newErrors.state = true;
    if (!form.pincode.trim() || form.pincode.length < 6) newErrors.pincode = true;
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleContinue = () => {
    if (validateStep1()) setStep("payment");
  };

  const handlePlaceOrder = async () => {
    if (items.length === 0) {
      toast.error("Your cart is empty.");
      return;
    }

    setIsPlacingOrder(true);
    try {
      const res = await fetch(`${API_BASE}/orders`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: session?.access_token
            ? `Bearer ${session.access_token}`
            : `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({
          items: items.map((i) => ({
            productId: i.productId,
            name: i.name,
            price: i.price,
            image: i.image,
            color: i.color,
            colorName: i.colorName,
            size: i.size,
            quantity: i.quantity,
          })),
          customerInfo: {
            name: form.name,
            email: form.email,
            phone: form.phone,
          },
          shippingAddress: {
            address: form.address,
            city: form.city,
            state: form.state,
            pincode: form.pincode,
          },
          paymentMethod,
          subtotal,
          shippingFee: shipping,
          total,
          sessionId,
          userId: user?.id || null,
        }),
      });

      const data = await res.json();

      if (!data.success) {
        throw new Error(data.error || "Failed to place order");
      }

      toast.success("Order placed successfully!");
      await clearCart();
      navigate(`/order-success?orderId=${data.data.orderId}`, {
        state: { order: data.data.order },
      });
    } catch (err) {
      console.log("Order placement error:", err);
      toast.error(`Failed to place order: ${err}`);
    } finally {
      setIsPlacingOrder(false);
    }
  };

  // Empty cart redirect
  if (items.length === 0) {
    return (
      <div
        style={{
          minHeight: "100vh",
          backgroundColor: "#0C0C0C",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: "24px",
          fontFamily: "'Inter', sans-serif",
          paddingTop: "80px",
        }}
      >
        <div style={{ fontSize: "64px" }}>🛒</div>
        <h2
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "32px",
            color: "#FFFFFF",
            margin: 0,
          }}
        >
          Your cart is empty
        </h2>
        <p
          style={{
            color: "rgba(255,255,255,0.45)",
            margin: 0,
            fontSize: "16px",
          }}
        >
          Add some items before checking out.
        </p>
        <Link
          to="/collection"
          style={{
            padding: "14px 32px",
            background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
            borderRadius: "10px",
            color: "#FFFFFF",
            textDecoration: "none",
            fontSize: "13px",
            fontWeight: 700,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
          }}
        >
          Browse Collection
        </Link>
      </div>
    );
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#0C0C0C",
        paddingTop: "80px",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Page Header */}
      <div
        style={{
          borderBottom: "1px solid rgba(255,255,255,0.05)",
          padding: "32px 0",
        }}
      >
        <div
          style={{
            maxWidth: "1440px",
            margin: "0 auto",
            padding: "0 48px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "24px" }}>
            <Link
              to="/collection"
              style={{
                display: "flex",
                alignItems: "center",
                gap: "6px",
                color: "rgba(255,255,255,0.5)",
                textDecoration: "none",
                fontSize: "13px",
                transition: "color 0.2s ease",
              }}
              onMouseEnter={(e) =>
                ((e.currentTarget as HTMLElement).style.color = "#FFFFFF")
              }
              onMouseLeave={(e) =>
                ((e.currentTarget as HTMLElement).style.color =
                  "rgba(255,255,255,0.5)")
              }
            >
              <ArrowLeft size={14} />
              Continue Shopping
            </Link>
            <div
              style={{
                height: "16px",
                width: "1px",
                background: "rgba(255,255,255,0.1)",
              }}
            />
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                textDecoration: "none",
              }}
            >
              <div
                style={{
                  width: "6px",
                  height: "6px",
                  borderRadius: "50%",
                  backgroundColor: "#4F8EF7",
                  boxShadow: "0 0 8px #4F8EF7",
                }}
              />
              <span
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "18px",
                  fontWeight: 700,
                  color: "#FFFFFF",
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                }}
              >
                Rupkala
              </span>
            </div>
          </div>

          {/* Secure badge */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "12px",
              color: "rgba(255,255,255,0.4)",
            }}
          >
            <Lock size={13} />
            Secure Checkout
          </div>
        </div>
      </div>

      {/* Step Indicator */}
      <div
        style={{
          maxWidth: "1440px",
          margin: "0 auto",
          padding: "28px 48px",
          display: "flex",
          alignItems: "center",
          gap: "8px",
        }}
      >
        {[
          { key: "details", label: "Shipping Details" },
          { key: "payment", label: "Payment" },
        ].map((s, i, arr) => (
          <div key={s.key} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                opacity: step === s.key || (s.key === "details") ? 1 : 0.5,
              }}
            >
              <div
                style={{
                  width: "24px",
                  height: "24px",
                  borderRadius: "50%",
                  background:
                    step === s.key
                      ? "linear-gradient(135deg, #4F8EF7, #7B6CF6)"
                      : step === "payment" && s.key === "details"
                      ? "#22C55E"
                      : "rgba(255,255,255,0.1)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "11px",
                  fontWeight: 700,
                  color: "#FFFFFF",
                  flexShrink: 0,
                }}
              >
                {step === "payment" && s.key === "details" ? (
                  <CheckCircle size={14} />
                ) : (
                  i + 1
                )}
              </div>
              <span
                style={{
                  fontSize: "13px",
                  fontWeight: step === s.key ? 600 : 400,
                  color: step === s.key ? "#FFFFFF" : "rgba(255,255,255,0.45)",
                }}
              >
                {s.label}
              </span>
            </div>
            {i < arr.length - 1 && (
              <ChevronRight size={16} color="rgba(255,255,255,0.2)" />
            )}
          </div>
        ))}
      </div>

      {/* Main Content */}
      <div
        style={{
          maxWidth: "1440px",
          margin: "0 auto",
          padding: "0 48px 80px",
          display: "grid",
          gridTemplateColumns: "1fr 420px",
          gap: "48px",
          alignItems: "start",
        }}
        className="grid-cols-1 lg:grid-cols-[1fr_420px]"
      >
        {/* ── Left: Form ── */}
        <div>
          {step === "details" && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              {/* Contact Info */}
              <div
                style={{
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: "20px",
                  padding: "32px",
                  marginBottom: "20px",
                }}
              >
                <h2
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "22px",
                    fontWeight: 700,
                    color: "#FFFFFF",
                    margin: "0 0 24px",
                  }}
                >
                  Contact Information
                </h2>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: "16px",
                  }}
                >
                  <InputField
                    label="Full Name"
                    value={form.name}
                    onChange={updateField("name")}
                    placeholder="Your full name"
                    required
                    error={errors.name}
                    colSpan={2}
                  />
                  <InputField
                    label="Email Address"
                    value={form.email}
                    onChange={updateField("email")}
                    placeholder="your@email.com"
                    type="email"
                    required
                    error={errors.email}
                  />
                  <InputField
                    label="Phone Number"
                    value={form.phone}
                    onChange={updateField("phone")}
                    placeholder="+91 00000 00000"
                    type="tel"
                    required
                    error={errors.phone}
                  />
                </div>
              </div>

              {/* Shipping Address */}
              <div
                style={{
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: "20px",
                  padding: "32px",
                  marginBottom: "28px",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    marginBottom: "24px",
                  }}
                >
                  <Truck size={18} color="#4F8EF7" strokeWidth={1.5} />
                  <h2
                    style={{
                      fontFamily: "'Playfair Display', serif",
                      fontSize: "22px",
                      fontWeight: 700,
                      color: "#FFFFFF",
                      margin: 0,
                    }}
                  >
                    Shipping Address
                  </h2>
                </div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: "16px",
                  }}
                >
                  <InputField
                    label="Street Address"
                    value={form.address}
                    onChange={updateField("address")}
                    placeholder="House no., Street, Area"
                    required
                    error={errors.address}
                    colSpan={2}
                  />
                  <InputField
                    label="City"
                    value={form.city}
                    onChange={updateField("city")}
                    placeholder="Mumbai"
                    required
                    error={errors.city}
                  />
                  <InputField
                    label="State"
                    value={form.state}
                    onChange={updateField("state")}
                    placeholder="Maharashtra"
                    required
                    error={errors.state}
                  />
                  <InputField
                    label="PIN Code"
                    value={form.pincode}
                    onChange={updateField("pincode")}
                    placeholder="400001"
                    required
                    error={errors.pincode}
                  />
                </div>
              </div>

              <button
                onClick={handleContinue}
                style={{
                  width: "100%",
                  padding: "18px 24px",
                  background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
                  border: "none",
                  borderRadius: "12px",
                  color: "#FFFFFF",
                  fontSize: "14px",
                  fontWeight: 700,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "10px",
                  boxShadow: "0 8px 32px rgba(79,142,247,0.4)",
                  fontFamily: "'Inter', sans-serif",
                  transition: "all 0.3s ease",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.transform =
                    "translateY(-2px)";
                  (e.currentTarget as HTMLElement).style.boxShadow =
                    "0 12px 40px rgba(79,142,247,0.5)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.transform =
                    "translateY(0)";
                  (e.currentTarget as HTMLElement).style.boxShadow =
                    "0 8px 32px rgba(79,142,247,0.4)";
                }}
              >
                Continue to Payment
                <ChevronRight size={18} />
              </button>
            </motion.div>
          )}

          {step === "payment" && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              {/* Shipping Summary */}
              <button
                onClick={() => setStep("details")}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: "10px",
                  padding: "12px 18px",
                  color: "rgba(255,255,255,0.6)",
                  fontSize: "13px",
                  cursor: "pointer",
                  fontFamily: "'Inter', sans-serif",
                  marginBottom: "24px",
                  transition: "all 0.2s ease",
                  width: "auto",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.color = "#FFFFFF";
                  (e.currentTarget as HTMLElement).style.borderColor =
                    "rgba(255,255,255,0.2)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.color =
                    "rgba(255,255,255,0.6)";
                  (e.currentTarget as HTMLElement).style.borderColor =
                    "rgba(255,255,255,0.08)";
                }}
              >
                <ArrowLeft size={14} />
                Edit shipping details
              </button>

              {/* Shipping confirmed card */}
              <div
                style={{
                  background: "rgba(34,197,94,0.04)",
                  border: "1px solid rgba(34,197,94,0.15)",
                  borderRadius: "14px",
                  padding: "16px 20px",
                  marginBottom: "24px",
                  display: "flex",
                  alignItems: "flex-start",
                  gap: "12px",
                }}
              >
                <CheckCircle
                  size={18}
                  color="#22C55E"
                  style={{ flexShrink: 0, marginTop: "2px" }}
                />
                <div>
                  <div
                    style={{
                      fontSize: "13px",
                      fontWeight: 600,
                      color: "#22C55E",
                      marginBottom: "4px",
                    }}
                  >
                    Shipping to {form.city}, {form.state}
                  </div>
                  <div
                    style={{ fontSize: "12px", color: "rgba(255,255,255,0.45)" }}
                  >
                    {form.name} · {form.phone} · {form.address}, {form.pincode}
                  </div>
                </div>
              </div>

              {/* Payment Methods */}
              <div
                style={{
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: "20px",
                  padding: "32px",
                  marginBottom: "24px",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    marginBottom: "28px",
                  }}
                >
                  <Shield size={18} color="#4F8EF7" strokeWidth={1.5} />
                  <h2
                    style={{
                      fontFamily: "'Playfair Display', serif",
                      fontSize: "22px",
                      fontWeight: 700,
                      color: "#FFFFFF",
                      margin: 0,
                    }}
                  >
                    Payment Method
                  </h2>
                </div>

                {/* Payment options */}
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "12px",
                    marginBottom: "28px",
                  }}
                >
                  {[
                    {
                      key: "upi" as PaymentMethod,
                      icon: Smartphone,
                      label: "UPI / Google Pay / PhonePe",
                      sub: "Instant payment via UPI",
                    },
                    {
                      key: "card" as PaymentMethod,
                      icon: CreditCard,
                      label: "Credit / Debit Card",
                      sub: "Visa, Mastercard, RuPay",
                    },
                    {
                      key: "cod" as PaymentMethod,
                      icon: Banknote,
                      label: "Cash on Delivery",
                      sub: "Pay when your order arrives",
                    },
                  ].map(({ key, icon: Icon, label, sub }) => (
                    <div
                      key={key}
                      onClick={() => setPaymentMethod(key)}
                      style={{
                        padding: "18px 20px",
                        background:
                          paymentMethod === key
                            ? "rgba(79,142,247,0.08)"
                            : "rgba(255,255,255,0.03)",
                        border: `1px solid ${
                          paymentMethod === key
                            ? "rgba(79,142,247,0.35)"
                            : "rgba(255,255,255,0.08)"
                        }`,
                        borderRadius: "12px",
                        display: "flex",
                        alignItems: "center",
                        gap: "16px",
                        cursor: "pointer",
                        transition: "all 0.25s ease",
                      }}
                      onMouseEnter={(e) => {
                        if (paymentMethod !== key) {
                          (e.currentTarget as HTMLElement).style.borderColor =
                            "rgba(255,255,255,0.15)";
                          (e.currentTarget as HTMLElement).style.background =
                            "rgba(255,255,255,0.05)";
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (paymentMethod !== key) {
                          (e.currentTarget as HTMLElement).style.borderColor =
                            "rgba(255,255,255,0.08)";
                          (e.currentTarget as HTMLElement).style.background =
                            "rgba(255,255,255,0.03)";
                        }
                      }}
                    >
                      {/* Radio */}
                      <div
                        style={{
                          width: "20px",
                          height: "20px",
                          borderRadius: "50%",
                          border: `2px solid ${
                            paymentMethod === key ? "#4F8EF7" : "rgba(255,255,255,0.2)"
                          }`,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                          transition: "border-color 0.2s ease",
                        }}
                      >
                        {paymentMethod === key && (
                          <div
                            style={{
                              width: "10px",
                              height: "10px",
                              borderRadius: "50%",
                              background: "#4F8EF7",
                            }}
                          />
                        )}
                      </div>

                      <Icon
                        size={20}
                        color={paymentMethod === key ? "#4F8EF7" : "rgba(255,255,255,0.5)"}
                        strokeWidth={1.5}
                      />

                      <div style={{ flex: 1 }}>
                        <div
                          style={{
                            fontSize: "14px",
                            fontWeight: 600,
                            color: "#FFFFFF",
                            marginBottom: "2px",
                          }}
                        >
                          {label}
                        </div>
                        <div
                          style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)" }}
                        >
                          {sub}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* UPI ID input */}
                {paymentMethod === "upi" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    style={{ marginBottom: "4px" }}
                  >
                    <InputField
                      label="UPI ID"
                      value={form.upiId || ""}
                      onChange={updateField("upiId")}
                      placeholder="yourname@upi"
                    />
                  </motion.div>
                )}

                {paymentMethod === "card" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                  >
                    <div
                      style={{
                        padding: "16px",
                        background: "rgba(255,255,255,0.03)",
                        borderRadius: "10px",
                        border: "1px solid rgba(255,255,255,0.06)",
                        display: "flex",
                        alignItems: "center",
                        gap: "10px",
                        fontSize: "13px",
                        color: "rgba(255,255,255,0.45)",
                      }}
                    >
                      <Lock size={14} />
                      Card details would be securely collected here in a
                      production environment with Razorpay or Stripe.
                    </div>
                  </motion.div>
                )}
              </div>

              {/* Place Order Button */}
              <button
                onClick={handlePlaceOrder}
                disabled={isPlacingOrder}
                style={{
                  width: "100%",
                  padding: "20px 24px",
                  background: isPlacingOrder
                    ? "rgba(79,142,247,0.5)"
                    : "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
                  border: "none",
                  borderRadius: "14px",
                  color: "#FFFFFF",
                  fontSize: "15px",
                  fontWeight: 700,
                  letterSpacing: "0.06em",
                  textTransform: "uppercase",
                  cursor: isPlacingOrder ? "not-allowed" : "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "12px",
                  boxShadow: isPlacingOrder
                    ? "none"
                    : "0 12px 40px rgba(79,142,247,0.45)",
                  fontFamily: "'Inter', sans-serif",
                  transition: "all 0.3s ease",
                }}
                onMouseEnter={(e) => {
                  if (!isPlacingOrder) {
                    (e.currentTarget as HTMLElement).style.transform =
                      "translateY(-2px)";
                    (e.currentTarget as HTMLElement).style.boxShadow =
                      "0 16px 48px rgba(79,142,247,0.55)";
                  }
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
                  (e.currentTarget as HTMLElement).style.boxShadow =
                    "0 12px 40px rgba(79,142,247,0.45)";
                }}
              >
                {isPlacingOrder ? (
                  <>
                    <div
                      style={{
                        width: "18px",
                        height: "18px",
                        border: "2px solid rgba(255,255,255,0.3)",
                        borderTop: "2px solid #FFFFFF",
                        borderRadius: "50%",
                        animation: "spin 0.7s linear infinite",
                      }}
                    />
                    Placing Order...
                  </>
                ) : (
                  <>
                    <Lock size={16} />
                    Place Order — ₹{total.toLocaleString("en-IN")}
                  </>
                )}
              </button>

              <p
                style={{
                  textAlign: "center",
                  fontSize: "11px",
                  color: "rgba(255,255,255,0.25)",
                  marginTop: "16px",
                }}
              >
                By placing this order, you agree to our Terms of Service and Privacy Policy.
                All transactions are secured with 256-bit encryption.
              </p>
            </motion.div>
          )}
        </div>

        {/* ── Right: Order Summary ── */}
        <div style={{ position: "sticky", top: "100px" }}>
          <div
            style={{
              background: "#111111",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: "20px",
              overflow: "hidden",
            }}
          >
            {/* Header */}
            <div
              style={{
                padding: "24px 24px 20px",
                borderBottom: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <h3
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "20px",
                  fontWeight: 700,
                  color: "#FFFFFF",
                  margin: 0,
                }}
              >
                Order Summary
              </h3>
              <p
                style={{
                  fontSize: "12px",
                  color: "rgba(255,255,255,0.4)",
                  margin: "4px 0 0",
                }}
              >
                {items.length} {items.length === 1 ? "item" : "items"}
              </p>
            </div>

            {/* Items */}
            <div
              style={{
                maxHeight: "300px",
                overflowY: "auto",
                padding: "8px 0",
              }}
            >
              {items.map((item) => (
                <div
                  key={`${item.productId}-${item.color}-${item.size}`}
                  style={{
                    padding: "16px 24px",
                    display: "flex",
                    gap: "14px",
                    alignItems: "flex-start",
                    borderBottom: "1px solid rgba(255,255,255,0.04)",
                  }}
                >
                  <div
                    style={{
                      width: "60px",
                      height: "72px",
                      borderRadius: "8px",
                      overflow: "hidden",
                      flexShrink: 0,
                      background: "#1A1A1A",
                      border: "1px solid rgba(255,255,255,0.06)",
                      position: "relative",
                    }}
                  >
                    {item.image && (
                      <img
                        src={item.image}
                        alt={item.name}
                        style={{
                          width: "100%",
                          height: "100%",
                          objectFit: "cover",
                        }}
                      />
                    )}
                    <div
                      style={{
                        position: "absolute",
                        top: "-6px",
                        right: "-6px",
                        background: "#4F8EF7",
                        color: "#FFFFFF",
                        fontSize: "9px",
                        fontWeight: 700,
                        width: "18px",
                        height: "18px",
                        borderRadius: "50%",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        border: "1.5px solid #111111",
                      }}
                    >
                      {item.quantity}
                    </div>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div
                      style={{
                        fontFamily: "'Playfair Display', serif",
                        fontSize: "14px",
                        fontWeight: 600,
                        color: "#FFFFFF",
                        marginBottom: "4px",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {item.name}
                    </div>
                    <div
                      style={{
                        fontSize: "11px",
                        color: "rgba(255,255,255,0.4)",
                        marginBottom: "6px",
                      }}
                    >
                      {item.colorName || item.color} · {item.size}
                    </div>
                    <div
                      style={{
                        fontSize: "14px",
                        fontWeight: 700,
                        color: "#FFFFFF",
                      }}
                    >
                      ₹{(item.price * item.quantity).toLocaleString("en-IN")}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Pricing */}
            <div style={{ padding: "20px 24px" }}>
              {/* Free shipping bar */}
              {shipping > 0 && (
                <div
                  style={{
                    padding: "12px 16px",
                    background: "rgba(79,142,247,0.05)",
                    border: "1px solid rgba(79,142,247,0.1)",
                    borderRadius: "10px",
                    marginBottom: "16px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      marginBottom: "8px",
                      fontSize: "11px",
                      color: "rgba(255,255,255,0.5)",
                    }}
                  >
                    <span>
                      ₹{SHIPPING_THRESHOLD - subtotal} away from free shipping
                    </span>
                    <span style={{ color: "#4F8EF7" }}>₹{SHIPPING_THRESHOLD}</span>
                  </div>
                  <div
                    style={{
                      height: "3px",
                      background: "rgba(255,255,255,0.08)",
                      borderRadius: "100px",
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        height: "100%",
                        width: `${Math.min((subtotal / SHIPPING_THRESHOLD) * 100, 100)}%`,
                        background: "linear-gradient(90deg, #4F8EF7, #7B6CF6)",
                        borderRadius: "100px",
                        transition: "width 0.5s ease",
                      }}
                    />
                  </div>
                </div>
              )}

              {[
                { label: "Subtotal", value: `₹${subtotal.toLocaleString("en-IN")}` },
                {
                  label: "Shipping",
                  value: shipping === 0 ? "FREE" : `₹${shipping}`,
                  valueColor: shipping === 0 ? "#22C55E" : undefined,
                },
              ].map(({ label, value, valueColor }) => (
                <div
                  key={label}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    marginBottom: "10px",
                  }}
                >
                  <span
                    style={{ fontSize: "13px", color: "rgba(255,255,255,0.45)" }}
                  >
                    {label}
                  </span>
                  <span
                    style={{
                      fontSize: "13px",
                      color: valueColor || "rgba(255,255,255,0.8)",
                      fontWeight: 500,
                    }}
                  >
                    {value}
                  </span>
                </div>
              ))}

              <div
                style={{
                  height: "1px",
                  background: "rgba(255,255,255,0.06)",
                  margin: "14px 0",
                }}
              />

              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <span style={{ fontSize: "15px", fontWeight: 600, color: "#FFFFFF" }}>
                  Total
                </span>
                <span
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "24px",
                    fontWeight: 800,
                    color: "#FFFFFF",
                  }}
                >
                  ₹{total.toLocaleString("en-IN")}
                </span>
              </div>

              <p
                style={{
                  textAlign: "center",
                  fontSize: "10px",
                  color: "rgba(255,255,255,0.2)",
                  margin: "14px 0 0",
                }}
              >
                All prices include GST · Made in India
              </p>
            </div>
          </div>
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
