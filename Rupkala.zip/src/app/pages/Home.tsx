import { Hero } from "../components/Hero";
import { Marquee } from "../components/Marquee";
import { FeaturedProducts } from "../components/FeaturedProducts";
import { CustomDesign } from "../components/CustomDesign";
import { BrandStory } from "../components/BrandStory";
import { Testimonials } from "../components/Testimonials";
import { Footer } from "../components/Footer";

export function Home() {
  return (
    <>
      <Hero />
      <Marquee />
      <FeaturedProducts />
      <CustomDesign />
      <BrandStory />
      <Testimonials />
      <Footer />
    </>
  );
}
