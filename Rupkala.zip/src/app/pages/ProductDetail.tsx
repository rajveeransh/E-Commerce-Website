import { useState, useEffect } from "react";
import {
  ShoppingBag,
  Heart,
  ArrowLeft,
  Truck,
  RotateCcw,
  Shield,
  Star,
  ChevronDown,
  ChevronUp,
  CheckCircle,
} from "lucide-react";
import { Link, useParams, useNavigate } from "react-router";
import { useCart } from "../context/CartContext";
import { projectId, publicAnonKey } from "/utils/supabase/info";
import { toast } from "sonner";
import { Footer } from "../components/Footer";
import { motion } from "motion/react";

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-40f0d309`;

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice: number | null;
  tag: string;
  tagColor: string;
  image: string;
  colors: string[];
  colorNames: string[];
  sizes: string[];
  category: string;
  rating: number;
  reviewCount: number;
  gsm: number;
  fit: string;
  inStock: boolean;
  description: string;
  features: string[];
}

const SIZE_GUIDE = {
  XS: { chest: "32-34", length: "26" },
  S: { chest: "35-37", length: "27" },
  M: { chest: "38-40", length: "28" },
  L: { chest: "41-43", length: "29" },
  XL: { chest: "44-46", length: "30" },
  XXL: { chest: "47-49", length: "31" },
};

function AccordionItem({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div
      style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
    >
      <button
        onClick={() => setOpen((v) => !v)}
        style={{
          width: "100%",
          padding: "18px 0",
          background: "none",
          border: "none",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          cursor: "pointer",
          color: "#FFFFFF",
          fontSize: "14px",
          fontWeight: 600,
          fontFamily: "'Inter', sans-serif",
          letterSpacing: "0.02em",
        }}
      >
        {title}
        {open ? (
          <ChevronUp size={16} color="rgba(255,255,255,0.5)" />
        ) : (
          <ChevronDown size={16} color="rgba(255,255,255,0.5)" />
        )}
      </button>
      {open && (
        <div style={{ paddingBottom: "20px" }}>{children}</div>
      )}
    </div>
  );
}

export function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart, openCart } = useCart();

  const [product, setProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  const [selectedColor, setSelectedColor] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>("");
  const [quantity, setQuantity] = useState(1);
  const [liked, setLiked] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const [sizeError, setSizeError] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    const fetchProduct = async () => {
      setIsLoading(true);
      setNotFound(false);
      try {
        const res = await fetch(`${API_BASE}/products/${id}`, {
          headers: { Authorization: `Bearer ${publicAnonKey}` },
        });
        const data = await res.json();
        if (data.success && data.data) {
          setProduct(data.data);
          // Set default size to middle option
          const sizes = data.data.sizes;
          setSelectedSize(sizes[Math.floor(sizes.length / 2)] || "");
        } else {
          setNotFound(true);
        }
      } catch (err) {
        console.log("Error fetching product:", err);
        setNotFound(true);
      } finally {
        setIsLoading(false);
      }
    };
    if (id) fetchProduct();
  }, [id]);

  const handleAddToCart = () => {
    if (!selectedSize) {
      setSizeError(true);
      toast.error("Please select a size", { duration: 2000 });
      return;
    }
    if (!product) return;

    setSizeError(false);
    addToCart({
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      color: product.colors[selectedColor],
      colorName: product.colorNames?.[selectedColor] || product.colors[selectedColor],
      size: selectedSize,
      quantity,
    });

    setAddedToCart(true);
    toast.success(`${product.name} added to cart!`);
    setTimeout(() => {
      setAddedToCart(false);
      openCart();
    }, 1200);
  };

  const discount = product?.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : null;

  // ── Loading State ────────────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div
        style={{
          minHeight: "100vh",
          backgroundColor: "#0C0C0C",
          paddingTop: "80px",
          fontFamily: "'Inter', sans-serif",
        }}
      >
        <div
          style={{
            maxWidth: "1440px",
            margin: "0 auto",
            padding: "60px 48px",
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "80px",
          }}
        >
          {[0, 1].map((i) => (
            <div
              key={i}
              style={{
                background:
                  "linear-gradient(110deg, #1A1A1A 30%, #222 50%, #1A1A1A 70%)",
                backgroundSize: "200% 100%",
                animation: "shimmer 1.5s infinite",
                borderRadius: "20px",
                height: i === 0 ? "560px" : "400px",
              }}
            />
          ))}
        </div>
        <style>{`@keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }`}</style>
      </div>
    );
  }

  // ── Not Found ────────────────────────────────────────────────────────────────
  if (notFound || !product) {
    return (
      <div
        style={{
          minHeight: "100vh",
          backgroundColor: "#0C0C0C",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: "24px",
          fontFamily: "'Inter', sans-serif",
          paddingTop: "80px",
        }}
      >
        <div style={{ fontSize: "64px" }}>🧵</div>
        <h1
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "36px",
            color: "#FFFFFF",
            margin: 0,
          }}
        >
          Product not found
        </h1>
        <p style={{ color: "rgba(255,255,255,0.45)", margin: 0 }}>
          This product may have sold out or been removed.
        </p>
        <Link
          to="/collection"
          style={{
            padding: "14px 32px",
            background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
            borderRadius: "8px",
            color: "#FFFFFF",
            textDecoration: "none",
            fontSize: "13px",
            fontWeight: 600,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
          }}
        >
          Browse Collection
        </Link>
      </div>
    );
  }

  // ── Main Render ──────────────────────────────────────────────────────────────
  return (
    <>
      <div
        style={{
          backgroundColor: "#0C0C0C",
          minHeight: "100vh",
          paddingTop: "80px",
          fontFamily: "'Inter', sans-serif",
        }}
      >
        <div
          style={{
            maxWidth: "1440px",
            margin: "0 auto",
            padding: "0 48px",
          }}
        >
          {/* Breadcrumb */}
          <div
            style={{
              padding: "32px 0 48px",
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "12px",
              color: "rgba(255,255,255,0.35)",
              fontFamily: "'Inter', sans-serif",
            }}
          >
            <button
              onClick={() => navigate(-1)}
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                color: "rgba(255,255,255,0.5)",
                display: "flex",
                alignItems: "center",
                gap: "6px",
                fontSize: "12px",
                padding: 0,
                fontFamily: "'Inter', sans-serif",
                transition: "color 0.2s ease",
              }}
              onMouseEnter={(e) =>
                ((e.currentTarget as HTMLElement).style.color = "#FFFFFF")
              }
              onMouseLeave={(e) =>
                ((e.currentTarget as HTMLElement).style.color =
                  "rgba(255,255,255,0.5)")
              }
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <span>/</span>
            <Link
              to="/collection"
              style={{
                color: "rgba(255,255,255,0.35)",
                textDecoration: "none",
                transition: "color 0.2s",
              }}
              onMouseEnter={(e) =>
                ((e.currentTarget as HTMLElement).style.color = "#FFFFFF")
              }
              onMouseLeave={(e) =>
                ((e.currentTarget as HTMLElement).style.color =
                  "rgba(255,255,255,0.35)")
              }
            >
              Collection
            </Link>
            <span>/</span>
            <span style={{ color: "rgba(255,255,255,0.6)" }}>{product.name}</span>
          </div>

          {/* Main grid */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "80px",
              alignItems: "start",
              paddingBottom: "120px",
            }}
            className="grid-cols-1 lg:grid-cols-2"
          >
            {/* ── Left: Image ── */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              style={{ position: "sticky", top: "100px" }}
            >
              <div
                style={{
                  borderRadius: "24px",
                  overflow: "hidden",
                  position: "relative",
                  border: "1px solid rgba(255,255,255,0.08)",
                  background: "#141414",
                }}
              >
                <img
                  src={product.image}
                  alt={product.name}
                  style={{
                    width: "100%",
                    aspectRatio: "3/4",
                    objectFit: "cover",
                    display: "block",
                    filter: "contrast(1.04) brightness(0.96)",
                  }}
                />

                {/* Tag */}
                <div
                  style={{
                    position: "absolute",
                    top: "20px",
                    left: "20px",
                    background: product.tagColor,
                    color: "#fff",
                    fontSize: "11px",
                    fontWeight: 700,
                    letterSpacing: "0.12em",
                    textTransform: "uppercase",
                    padding: "6px 14px",
                    borderRadius: "100px",
                  }}
                >
                  {product.tag}
                </div>

                {/* Wishlist */}
                <button
                  onClick={() => {
                    setLiked(!liked);
                    toast(liked ? "Removed from wishlist" : "Added to wishlist!");
                  }}
                  style={{
                    position: "absolute",
                    top: "20px",
                    right: "20px",
                    width: "44px",
                    height: "44px",
                    borderRadius: "50%",
                    background: "rgba(12,12,12,0.7)",
                    backdropFilter: "blur(12px)",
                    border: `1.5px solid ${liked ? "#E63946" : "rgba(255,255,255,0.1)"}`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    color: liked ? "#E63946" : "rgba(255,255,255,0.7)",
                    transition: "all 0.2s ease",
                  }}
                >
                  <Heart size={18} fill={liked ? "currentColor" : "none"} />
                </button>

                {/* Discount badge */}
                {discount && (
                  <div
                    style={{
                      position: "absolute",
                      bottom: "20px",
                      left: "20px",
                      background: "#E63946",
                      color: "#fff",
                      fontSize: "12px",
                      fontWeight: 700,
                      padding: "6px 14px",
                      borderRadius: "100px",
                    }}
                  >
                    -{discount}% OFF
                  </div>
                )}
              </div>

              {/* Trust badges below image */}
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(3, 1fr)",
                  gap: "12px",
                  marginTop: "20px",
                }}
              >
                {[
                  { icon: Truck, label: "Free Delivery", sub: "On orders ₹999+" },
                  { icon: RotateCcw, label: "Easy Returns", sub: "7-day window" },
                  { icon: Shield, label: "Quality Assured", sub: "100% genuine" },
                ].map(({ icon: Icon, label, sub }) => (
                  <div
                    key={label}
                    style={{
                      background: "rgba(255,255,255,0.025)",
                      border: "1px solid rgba(255,255,255,0.06)",
                      borderRadius: "12px",
                      padding: "16px 12px",
                      textAlign: "center",
                    }}
                  >
                    <Icon
                      size={18}
                      color="#4F8EF7"
                      strokeWidth={1.5}
                      style={{ marginBottom: "8px" }}
                    />
                    <div
                      style={{
                        fontSize: "11px",
                        fontWeight: 600,
                        color: "#FFFFFF",
                        marginBottom: "2px",
                      }}
                    >
                      {label}
                    </div>
                    <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.35)" }}>
                      {sub}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* ── Right: Details ── */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              {/* Category tag */}
              <p
                style={{
                  fontSize: "11px",
                  color: "#4F8EF7",
                  fontWeight: 600,
                  letterSpacing: "0.2em",
                  textTransform: "uppercase",
                  marginBottom: "16px",
                }}
              >
                {product.category} · {product.fit} Fit · {product.gsm}GSM
              </p>

              {/* Product name */}
              <h1
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "clamp(32px, 4vw, 48px)",
                  fontWeight: 800,
                  color: "#FFFFFF",
                  margin: "0 0 16px",
                  lineHeight: 1.1,
                  letterSpacing: "-0.02em",
                }}
              >
                {product.name}
              </h1>

              {/* Rating */}
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  marginBottom: "28px",
                }}
              >
                <div style={{ display: "flex", gap: "3px" }}>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      size={14}
                      fill={i < Math.floor(product.rating) ? "#F59E0B" : "none"}
                      color="#F59E0B"
                      strokeWidth={1.5}
                    />
                  ))}
                </div>
                <span
                  style={{
                    fontSize: "13px",
                    color: "rgba(255,255,255,0.6)",
                    fontWeight: 500,
                  }}
                >
                  {product.rating} ({product.reviewCount} reviews)
                </span>
              </div>

              {/* Price */}
              <div
                style={{
                  display: "flex",
                  alignItems: "baseline",
                  gap: "12px",
                  marginBottom: "32px",
                  paddingBottom: "32px",
                  borderBottom: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <span
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "38px",
                    fontWeight: 800,
                    color: "#FFFFFF",
                    lineHeight: 1,
                  }}
                >
                  ₹{product.price.toLocaleString("en-IN")}
                </span>
                {product.originalPrice && (
                  <>
                    <span
                      style={{
                        fontSize: "20px",
                        color: "rgba(255,255,255,0.3)",
                        textDecoration: "line-through",
                      }}
                    >
                      ₹{product.originalPrice.toLocaleString("en-IN")}
                    </span>
                    <span
                      style={{
                        fontSize: "13px",
                        color: "#22C55E",
                        fontWeight: 700,
                        background: "rgba(34,197,94,0.1)",
                        border: "1px solid rgba(34,197,94,0.2)",
                        padding: "3px 10px",
                        borderRadius: "100px",
                      }}
                    >
                      {discount}% OFF
                    </span>
                  </>
                )}
              </div>

              {/* Color Selector */}
              <div style={{ marginBottom: "28px" }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    marginBottom: "14px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "12px",
                      fontWeight: 600,
                      color: "rgba(255,255,255,0.6)",
                      letterSpacing: "0.12em",
                      textTransform: "uppercase",
                    }}
                  >
                    Color
                  </span>
                  <span
                    style={{
                      fontSize: "13px",
                      fontWeight: 600,
                      color: "#FFFFFF",
                    }}
                  >
                    {product.colorNames?.[selectedColor] ||
                      product.colors[selectedColor]}
                  </span>
                </div>
                <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
                  {product.colors.map((color, i) => (
                    <button
                      key={i}
                      onClick={() => setSelectedColor(i)}
                      title={product.colorNames?.[i] || color}
                      style={{
                        width: "40px",
                        height: "40px",
                        borderRadius: "50%",
                        backgroundColor: color,
                        border:
                          selectedColor === i
                            ? "2px solid #4F8EF7"
                            : "2px solid rgba(255,255,255,0.12)",
                        cursor: "pointer",
                        transition: "all 0.2s ease",
                        transform: selectedColor === i ? "scale(1.15)" : "scale(1)",
                        boxShadow:
                          selectedColor === i
                            ? "0 0 0 3px rgba(79,142,247,0.2)"
                            : "none",
                        position: "relative",
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Size Selector */}
              <div style={{ marginBottom: "32px" }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    marginBottom: "14px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "12px",
                      fontWeight: 600,
                      color: sizeError
                        ? "#E63946"
                        : "rgba(255,255,255,0.6)",
                      letterSpacing: "0.12em",
                      textTransform: "uppercase",
                      transition: "color 0.2s ease",
                    }}
                  >
                    Size{sizeError ? " — Please select a size" : ""}
                  </span>
                </div>
                <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => {
                        setSelectedSize(size);
                        setSizeError(false);
                      }}
                      style={{
                        width: "52px",
                        height: "52px",
                        borderRadius: "10px",
                        background:
                          selectedSize === size
                            ? "linear-gradient(135deg, #4F8EF7, #7B6CF6)"
                            : sizeError
                            ? "rgba(230,57,70,0.08)"
                            : "rgba(255,255,255,0.04)",
                        border:
                          selectedSize === size
                            ? "none"
                            : sizeError
                            ? "1px solid rgba(230,57,70,0.3)"
                            : "1px solid rgba(255,255,255,0.1)",
                        color: selectedSize === size
                          ? "#FFFFFF"
                          : "rgba(255,255,255,0.7)",
                        fontSize: "13px",
                        fontWeight: selectedSize === size ? 700 : 500,
                        cursor: "pointer",
                        transition: "all 0.2s ease",
                        fontFamily: "'Inter', sans-serif",
                        boxShadow:
                          selectedSize === size
                            ? "0 4px 16px rgba(79,142,247,0.35)"
                            : "none",
                      }}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity + Add to Cart */}
              <div
                style={{
                  display: "flex",
                  gap: "12px",
                  marginBottom: "24px",
                  alignItems: "stretch",
                }}
              >
                {/* Quantity */}
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    background: "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "10px",
                    overflow: "hidden",
                    flexShrink: 0,
                  }}
                >
                  <button
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    style={{
                      width: "44px",
                      height: "56px",
                      background: "none",
                      border: "none",
                      color:
                        quantity === 1
                          ? "rgba(255,255,255,0.2)"
                          : "rgba(255,255,255,0.7)",
                      fontSize: "20px",
                      cursor: quantity === 1 ? "not-allowed" : "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      transition: "color 0.2s ease",
                    }}
                    disabled={quantity === 1}
                  >
                    −
                  </button>
                  <span
                    style={{
                      minWidth: "40px",
                      textAlign: "center",
                      fontSize: "16px",
                      fontWeight: 700,
                      color: "#FFFFFF",
                    }}
                  >
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity((q) => Math.min(10, q + 1))}
                    style={{
                      width: "44px",
                      height: "56px",
                      background: "none",
                      border: "none",
                      color: "rgba(255,255,255,0.7)",
                      fontSize: "20px",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      transition: "color 0.2s ease",
                    }}
                  >
                    +
                  </button>
                </div>

                {/* Add to Cart */}
                <button
                  onClick={handleAddToCart}
                  style={{
                    flex: 1,
                    padding: "16px 24px",
                    background: addedToCart
                      ? "linear-gradient(135deg, #22C55E, #16A34A)"
                      : "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
                    border: "none",
                    borderRadius: "10px",
                    color: "#FFFFFF",
                    fontSize: "14px",
                    fontWeight: 700,
                    letterSpacing: "0.08em",
                    textTransform: "uppercase",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "10px",
                    transition: "all 0.3s ease",
                    boxShadow: addedToCart
                      ? "0 8px 32px rgba(34,197,94,0.4)"
                      : "0 8px 32px rgba(79,142,247,0.4)",
                    fontFamily: "'Inter', sans-serif",
                  }}
                  onMouseEnter={(e) => {
                    if (!addedToCart) {
                      (e.currentTarget as HTMLElement).style.transform =
                        "translateY(-2px)";
                      (e.currentTarget as HTMLElement).style.boxShadow =
                        "0 12px 40px rgba(79,142,247,0.5)";
                    }
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.transform =
                      "translateY(0)";
                    (e.currentTarget as HTMLElement).style.boxShadow =
                      "0 8px 32px rgba(79,142,247,0.4)";
                  }}
                >
                  {addedToCart ? (
                    <>
                      <CheckCircle size={18} />
                      Added to Cart!
                    </>
                  ) : (
                    <>
                      <ShoppingBag size={18} strokeWidth={1.8} />
                      Add to Cart — ₹
                      {(product.price * quantity).toLocaleString("en-IN")}
                    </>
                  )}
                </button>
              </div>

              {/* Buy Now */}
              <button
                onClick={() => {
                  handleAddToCart();
                }}
                style={{
                  width: "100%",
                  padding: "16px 24px",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "10px",
                  color: "#FFFFFF",
                  fontSize: "14px",
                  fontWeight: 600,
                  letterSpacing: "0.05em",
                  cursor: "pointer",
                  fontFamily: "'Inter', sans-serif",
                  transition: "all 0.2s ease",
                  marginBottom: "40px",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.background =
                    "rgba(255,255,255,0.08)";
                  (e.currentTarget as HTMLElement).style.borderColor =
                    "rgba(255,255,255,0.2)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.background =
                    "rgba(255,255,255,0.04)";
                  (e.currentTarget as HTMLElement).style.borderColor =
                    "rgba(255,255,255,0.1)";
                }}
              >
                Buy Now
              </button>

              {/* Accordion Details */}
              <div
                style={{
                  borderTop: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <AccordionItem title="Product Description">
                  <p
                    style={{
                      fontSize: "14px",
                      color: "rgba(255,255,255,0.55)",
                      lineHeight: 1.8,
                      margin: 0,
                    }}
                  >
                    {product.description}
                  </p>
                </AccordionItem>

                <AccordionItem title="Key Features">
                  <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
                    {product.features?.map((f, i) => (
                      <li
                        key={i}
                        style={{
                          display: "flex",
                          alignItems: "flex-start",
                          gap: "10px",
                          fontSize: "14px",
                          color: "rgba(255,255,255,0.55)",
                          marginBottom: "10px",
                          lineHeight: 1.5,
                        }}
                      >
                        <span style={{ color: "#4F8EF7", marginTop: "2px", flexShrink: 0 }}>
                          ✦
                        </span>
                        {f}
                      </li>
                    ))}
                  </ul>
                </AccordionItem>

                <AccordionItem title="Size Guide">
                  <div style={{ overflowX: "auto" }}>
                    <table
                      style={{
                        width: "100%",
                        borderCollapse: "collapse",
                        fontSize: "12px",
                        color: "rgba(255,255,255,0.6)",
                      }}
                    >
                      <thead>
                        <tr>
                          {["Size", "Chest (in)", "Length (in)"].map((h) => (
                            <th
                              key={h}
                              style={{
                                padding: "8px 12px",
                                background: "rgba(255,255,255,0.04)",
                                borderRadius: "4px",
                                textAlign: "left",
                                fontWeight: 600,
                                color: "rgba(255,255,255,0.7)",
                                letterSpacing: "0.05em",
                              }}
                            >
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {product.sizes.map((size) => (
                          <tr key={size}>
                            <td
                              style={{
                                padding: "10px 12px",
                                fontWeight: 600,
                                color:
                                  selectedSize === size ? "#4F8EF7" : "#FFFFFF",
                              }}
                            >
                              {size}
                            </td>
                            <td style={{ padding: "10px 12px" }}>
                              {SIZE_GUIDE[size as keyof typeof SIZE_GUIDE]?.chest || "—"}
                            </td>
                            <td style={{ padding: "10px 12px" }}>
                              {SIZE_GUIDE[size as keyof typeof SIZE_GUIDE]?.length || "—"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </AccordionItem>

                <AccordionItem title="Shipping & Returns">
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "12px",
                    }}
                  >
                    {[
                      { label: "Standard Delivery", value: "5–7 working days" },
                      {
                        label: "Free Shipping",
                        value: "On all orders above ₹999",
                      },
                      { label: "Express Delivery", value: "2–3 days (₹149 extra)" },
                      {
                        label: "Returns",
                        value: "Easy 7-day return window",
                      },
                    ].map(({ label, value }) => (
                      <div
                        key={label}
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          fontSize: "13px",
                        }}
                      >
                        <span style={{ color: "rgba(255,255,255,0.45)" }}>
                          {label}
                        </span>
                        <span
                          style={{ color: "rgba(255,255,255,0.75)", fontWeight: 500 }}
                        >
                          {value}
                        </span>
                      </div>
                    ))}
                  </div>
                </AccordionItem>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
