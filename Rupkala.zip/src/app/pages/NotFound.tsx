import { Link } from "react-router";
import { ArrowLeft, Home, Search } from "lucide-react";
import { motion } from "motion/react";

export function NotFound() {
  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#0C0C0C",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "48px",
        fontFamily: "'Inter', sans-serif",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Background glow */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "600px",
          height: "600px",
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(79,142,247,0.05) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      {/* Watermark */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          pointerEvents: "none",
          overflow: "hidden",
        }}
      >
        <span
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(120px, 20vw, 280px)",
            fontWeight: 900,
            color: "rgba(255,255,255,0.015)",
            letterSpacing: "-0.04em",
            whiteSpace: "nowrap",
            userSelect: "none",
          }}
        >
          404
        </span>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        style={{ textAlign: "center", position: "relative", zIndex: 1 }}
      >
        {/* Error code */}
        <div
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "8px",
            background: "rgba(230,57,70,0.08)",
            border: "1px solid rgba(230,57,70,0.2)",
            borderRadius: "100px",
            padding: "6px 16px",
            marginBottom: "32px",
          }}
        >
          <span
            style={{
              width: "6px",
              height: "6px",
              borderRadius: "50%",
              backgroundColor: "#E63946",
              display: "inline-block",
            }}
          />
          <span
            style={{
              fontSize: "11px",
              color: "#E63946",
              fontWeight: 600,
              letterSpacing: "0.15em",
              textTransform: "uppercase",
            }}
          >
            Page Not Found
          </span>
        </div>

        <h1
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(40px, 6vw, 72px)",
            fontWeight: 800,
            color: "#FFFFFF",
            margin: "0 0 24px",
            lineHeight: 1.1,
            letterSpacing: "-0.02em",
          }}
        >
          Lost in the{" "}
          <span
            style={{
              background: "linear-gradient(135deg, #4F8EF7 0%, #7B6CF6 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              fontStyle: "italic",
            }}
          >
            fabric.
          </span>
        </h1>

        <p
          style={{
            fontSize: "17px",
            color: "rgba(255,255,255,0.45)",
            lineHeight: 1.75,
            margin: "0 auto 48px",
            maxWidth: "440px",
          }}
        >
          The page you're looking for has gone off the rack. Let's get you
          back to the collection.
        </p>

        <div
          style={{ display: "flex", gap: "16px", justifyContent: "center", flexWrap: "wrap" }}
        >
          <Link
            to="/"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "10px",
              padding: "16px 32px",
              background: "linear-gradient(135deg, #4F8EF7, #7B6CF6)",
              borderRadius: "10px",
              color: "#FFFFFF",
              textDecoration: "none",
              fontSize: "13px",
              fontWeight: 700,
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              boxShadow: "0 8px 32px rgba(79,142,247,0.4)",
              transition: "all 0.3s ease",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)";
              (e.currentTarget as HTMLElement).style.boxShadow =
                "0 12px 40px rgba(79,142,247,0.5)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
              (e.currentTarget as HTMLElement).style.boxShadow =
                "0 8px 32px rgba(79,142,247,0.4)";
            }}
          >
            <Home size={16} />
            Back to Home
          </Link>

          <Link
            to="/collection"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "10px",
              padding: "16px 32px",
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "10px",
              color: "rgba(255,255,255,0.7)",
              textDecoration: "none",
              fontSize: "13px",
              fontWeight: 600,
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.borderColor =
                "rgba(255,255,255,0.25)";
              (e.currentTarget as HTMLElement).style.color = "#FFFFFF";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.borderColor =
                "rgba(255,255,255,0.1)";
              (e.currentTarget as HTMLElement).style.color =
                "rgba(255,255,255,0.7)";
            }}
          >
            <Search size={16} />
            Browse Collection
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
