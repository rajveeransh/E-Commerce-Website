import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Marquee } from "./components/Marquee";
import { FeaturedProducts } from "./components/FeaturedProducts";
import { CustomDesign } from "./components/CustomDesign";
import { BrandStory } from "./components/BrandStory";
import { Testimonials } from "./components/Testimonials";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div
      style={{
        backgroundColor: "#0C0C0C",
        minHeight: "100vh",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* ── Navigation ──────────────────────────────── */}
      <Navbar />

      {/* ── Hero ────────────────────────────────────── */}
      <Hero />

      {/* ── Marquee ticker ──────────────────────────── */}
      <Marquee />

      {/* ── Featured Products ───────────────────────── */}
      <FeaturedProducts />

      {/* ── Custom Design Studio ────────────────────── */}
      <CustomDesign />

      {/* ── Brand Story ─────────────────────────────── */}
      <BrandStory />

      {/* ── Testimonials ────────────────────────────── */}
      <Testimonials />

      {/* ── Footer ──────────────────────────────────── */}
      <Footer />
    </div>
  );
}
