
  # Rupkala

  This is a code bundle for Rupkala. The original project is available at https://www.figma.com/design/7qRhQUSIVbgQDMNrzvlJ24/Rupkala.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  